package ve.unix.ula.mathematicaapp;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link frament_Tienda.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link frament_Tienda#newInstance} factory method to
 * create an instance of this fragment.
 */
public class frament_Tienda extends android.support.v4.app.Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private Usuario user;
    private TextView cantidad1, errorcantidad1;
    Context context;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public frament_Tienda() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment frament_Tienda.
     */
    // TODO: Rename and change types and number of parameters
    public static frament_Tienda newInstance(String param1, String param2) {
        frament_Tienda fragment = new frament_Tienda();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_frament__tienda, container, false);
        (rootView.findViewById(R.id.mas)).setOnClickListener(this);
        (rootView.findViewById(R.id.menos)).setOnClickListener(this);
        (rootView.findViewById(R.id.Comprar1)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono1)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono2)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono3)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono4)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono5)).setOnClickListener(this);
        (rootView.findViewById(R.id.icono6)).setOnClickListener(this);
        cantidad1 = (TextView) (rootView.findViewById(R.id.cantidad1));
        errorcantidad1 = (TextView) (rootView.findViewById(R.id.errorCantidad1));
        return rootView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        user  = new Usuario();
        this.context = context;
        try {
            if (!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(context.openFileInput("UsuariosActivos.txt"))))) {
                Intent intent = new Intent(context, Login.class);
                startActivity(intent);
            }

        } catch (IOException Error) {
            Log.e(Error.getMessage(), Error.getMessage());
        }
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }
    public void Recibir(Usuario user){
        if(user != null){
            this.user = user;
        }else{
            this.user = new Usuario();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.mas:
                cantidad1.setText( new Integer( new Integer (cantidad1.getText().toString()) +1).toString()  );
                break;
            case R.id.menos:
                if(cantidad1.getText().toString().equals("1")){
                    return;
                }
                cantidad1.setText( new Integer( new Integer (cantidad1.getText().toString()) -1).toString()  );
                break;
            case R.id.Comprar1:
                    if(!(user.getExp() < new Integer(cantidad1.getText().toString())*200)) {
                        AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                        Buider.setMessage("Quiere comprar " + cantidad1.getText() + " de potenciador1?\n Total a pagar:" + ""+new Integer(cantidad1.getText().toString())*200)
                                .setCancelable(false)
                                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        try {
                                            user.setExp(user.getExp() - (new Integer(cantidad1.getText().toString())*200));
                                            user.setNumeroDeSaltar(user.getNumeroDeSaltar() + new Integer(cantidad1.getText().toString()));
                                            user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                            mListener.ActualizaUsuarios(user);
                                        } catch (IOException error) {
                                            Log.e(error.getLocalizedMessage(), error.getMessage());
                                        }

                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //nada
                                    }
                                });
                        Buider.create().show();
                    }else{
                        Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este bonus",Toast.LENGTH_SHORT).show();
                    }


                break;

            case R.id.icono2:
                if(!(user.getExp() < 600)) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setIcono(2);
                                        user.setExp(user.getExp() - 600);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.icono4:
                if(!(user.getExp() < 600 )){
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setIcono(4);
                                        user.setExp(user.getExp() - 600);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.icono5:
                if(!(user.getExp() < 600)) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setIcono(5);
                                        user.setExp(user.getExp() - 600);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.icono6:
                if(!(user.getExp() < 600)) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setIcono(6);
                                        user.setExp(user.getExp() - 600);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.icono1:
                if(!(user.getExp() < 600)) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setExp(user.getExp() - 600);
                                        user.setIcono(1);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.icono3:
                if(!(user.getExp() < 600)) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(getContext());
                    Buider.setMessage("Quiere comprar de icono?\n Total a pagar:" + ""+600)
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    try {
                                        user.setExp(user.getExp() - 600);
                                        user.setIcono(3);
                                        user.UsuarioActivo(new OutputStreamWriter(getContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        mListener.ActualizaUsuarios(user);
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //nada
                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(this.context,"No tiene la cantidad de exp necesaria \npara adquirir este icono",Toast.LENGTH_SHORT).show();
                }


                break;





        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
        void ActualizaUsuarios(Usuario usuarios);
    }
}
