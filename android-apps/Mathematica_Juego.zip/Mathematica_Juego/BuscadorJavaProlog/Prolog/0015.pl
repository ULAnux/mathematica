%pr(_,['cual','es','el','dominio','de','funcion'],R,_,_).

pr(0015-1,['cual','es','el','dominio','de','funcion'],['el','dominio','de','una', 'funcion', 'f:X→Y','es','el', 'conjunto','de','existencia','de',' ella','misma,','es','decir,','los','valores','para','los','cuales','la','funcion','esta','definida.' ],20/20,'Rossangela Paola de las Mercedes Bellorin Labrador').
%pr(_,['cual','es','el','rango','o','recorrido'],R,_,_).
pr(0015-2,['cual','es','el','rango','o','recorrido'],['Se','denomina','rango','o','recorrido','de','una','función','al','conjunto','de','los','valores',' reales','que','toma','la','variable','y','o','f(x).'],20/20,'Rossangela Paola de las Mercedes Bellorin Labrador').
