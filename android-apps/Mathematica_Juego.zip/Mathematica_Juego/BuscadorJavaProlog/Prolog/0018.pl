% jesus herrera

	pr(0018-1,['�Que es una funcion?'], ['Es una relacion binaria porque asocia a cada argumento con un resultado unico llamado la imagen de una funcion'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).


	pr(0018-2,['�Cual es la notacion para indicar que el par (x,y) pertenece a alguna funcion f ?'], ['Es y =f(x) por lo tanto (x,y) pertenece a f e y=f(x) son sinonimos'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-3,['�Que es la preimagen de una  funcion ?'], ['Se define como preimagen al elemento del conjunto de partida F'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-4,['�Que es el rango?'], ['Es el conjunto de todos los puntos para  los cuales existe una preimagen que satisfacey=f(x)'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-5,['�Que es una funcion inyectiva ?'], ['Es una funcion que se relaciona uno a uno los elementos del conjunto de partida con los de llegada'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-6,['�Que es una funcion sobreyectiva?'], ['Es una funcion en la cual todo los  elementos del conjunto de llegada tiene una preimagen '],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-7,['�Que es una funcion Biyectiva?'], ['Es una funcion que es inyectiva y sobreyectiva al mismo tiempo'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-8,['�Que es la funcion inversa ?'], ['si F es una funcion que  al ser evaluada en una funcion g da 1 y si g al evaluarla en F da 1 esa son funciones inversas una de la otra'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-9,['�cuando una funcion tiene inversa?'], ['una funcion posee inversa cuando la  funcion es biyectiva'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-10,['�cual es la regla del producto?'], ['Supongamos que una tarea se puede  dividir en dos tareas consecutivas.Si hay n1  forma para realizar la primera tarea y n2 formas  de hecer la Segunda despues de haber realizado la  primera entonces hay n1*n2formas de completar la tarea '],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-11,['�cual es la regla de la suma ?'], ['Supongamos que una tarea se puede  realizar de n1 formas y una segunda tarea se  realiza de n2 formas y si las 2 tareas  son incompatibles entonces hay n1+n2 formas de  realizar una de las 2 tareas'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-12,['� Que es la permutacion de un conjunto?'], ['una permutacion de un conjunto de  objetos distinto es una ordenacion de esos objetos. Tambien nos interesan las posibles ordenaciones de un subconjunto de ellos'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-13,['�que es una combinatoria ?'], [ 'Una R-combinacion de elementos de  un conjunto es una seleccion sin ordenar de r elementos del conjunto es decir un subconjunto de R  elementos'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-14,['�que son relaciones de recurrencia ?'], [ 'Una Relacion de recurrencia para  la sucesion (An) es una ecuacion que determina el  termino An en funcion de los terminos anteriores es  decir A0,A1,A2...A(n-1) para todos los enteros n tales que n seamayor o igual a n0 donde n0 es entero positivo'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).

	pr(0018-15,['� que es una relacion de recurrencia lineal?'], [ 'Es una relacion homogenea de  orden K y con coeficiente constante es una relacion  de recurrencia de la forma:An=C1A(n-1)+C2A(n-2)+...+CkA(n-k) donde C1,C2,...,Ck son  numeros reales'],20/20,['jesus Herrera Basado en 2000 ejercicio de matematica discreta']).





% actualizacion 1.1





	pr(0018-16,['� A que se refiere la complejidad computacional ?'], ['Se centra en la clasificacion de los problemas computacionales de acuerdo a su dicultad y  en la relacion entre dichas clases de complejidad'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-17,['� Cuando un problema computacional es considerado dificil?'], ['Se considera dificil si su solucion requiere de una gran cantidad de recursos computacionales'],20/20,['jesus Herrera Basado en www.wikipedia.org']).



	pr(0018-18,['� cual es el objetivo de la complejidad computacional ?'], ['Clasificar los problemas que pueden o no pueden ser resuelto con una cantidad determinada de recursos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-19,['�Que es una complejidad de orden constante ?'], ['es cuando la compejidad del algoritmo puede expresarse como una constante esto quiere decir que  T(n)=a es constante porque no depende de n'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-20,['� un ejemplo basico de complejidad constante ?'], ['el procedimiento de cualquier operacion aritmetica como:return((a/b)*(n+m))'],20/20,['jesus Herrera ']).

	pr(0018-21,['�Que es una complejidad de orden lineal ?'], ['es cuando la compejidad de un algoritmo puede expresarse como un funcion lineal T(n)=a*n+b donde a  y b son constantes es lineal de n'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-22,['�un ejemplo basico de complejidad lineal ?'], ['cualquier procedimiento que utilice cualquier estructura de repeticion solo una vez'],20/20,['jesus Herrera ']).

	pr(0018-23,['�cuales son las estructuras basicas de repeticion ?'], ['tenemos 2:el while que se utiliza cuando no conocemos la cantidad que se va a repetir y el for en el  cual si se conoce la cantidad a repetir'],20/20,['jesus Herrera ']).

	pr(0018-24,['� Que es una complejidad de orden cuadratica ?'], ['es cuando la compejidad de un algoritmo puede expresarse como una funcion cuadratica T(n)=a*n^2+bn+c donde a,b y c son constantes es cuadratico de n'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-25,['� un ejemplo basico de complejidad cuadratica',  '?'], ['cualquier procedimiento que utilice 2 estructura de repeticion como el metodo de ordenamiento de la burbuja para mas detalle consulte este enlace: http://es.wikipedia.org/wiki/Ordenamiento_de_burbuja'],20/20,['jesus Herrera ']).


	pr(0018-26,['� Que es una complejidad de orden logaritmico ?'], ['es cuando la compejidad de un algoritmo puede expresarse como una funcion logaritmica T(n)=a*logn donde a  es constante es logaritmico de n'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-27,['�un ejemplo basico de complejidad logaritmica ?'], ['muchos de los procedimientos que son recursivos son de orden logaritmico tal como el metodo de ordenamiento quicksort para mas detalle consulte este enlace: http://es.wikipedia.org/wiki/Quicksort'],20/20,['jesus Herrera ']).

	pr(0018-28,['� que es el termino de divide y venceras ?'], ['hace referencia a uno de los paradigma de diseno de algoritmo. Sirviendo para resolver problema recursivos dividiendolo en dos o mas subproblema de igual tipo o similar esto continua hasta que se haga simple y al final se suma esas dichas soluciones' ],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-29,['� cual es el mejor de los casos que se nos puede presentar ?'], ['el mejor de los casos es que nos de orden constante'],20/20,['jesus Herrera ']).

	pr(0018-30,['� cual es el peor de los casos que se nos puede presentar ?'], ['el peor de los casos es que nos de orden exponencial'],20/20,['jesus Herrera ']).


%actualizacion 1.2


	pr(0018-31,['�que son las funciones generatrices ?'], ['es una forma de serie de potencia que codifican informacion sobre una sucesion exponencial An donde n son numeros enteros'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-32,['� que son series de potencia ?'], ['son aquellas funciones  las cuales podemos aproximarlas mediante polinomios en forma de serie'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-33,['�algunos tipos de funciones generatrices ?'], ['tenemos la funcion generadora ordinaria las funciones generadoras exponenciales la serie de lambert la serie de Bell y la serie de dirichlet'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-34,['� las funciones generatrices son funciones?'], ['No ya que no existe una relacion entre un dominio y un codominio'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-35,['� cita de Herbert wilf ?'], ['"una funcion generadora es una cuerda de tender en la que colgamos una sucession denumeros para mostrarla "'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-36,['� Algunas aplicaciones de las funciones generatrices','?'], ['encontrar una forma cerrada para una succesion, encontrar relaciones de recurrencia para succesiones,encontrar relaciones entre sucessiones demostrar identidades que implican sucessione,resolver problemas de enumeracion en combinatoria'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-37,['� Que es la induccion matematica ?'], ['es un razonamiento que  permite demostrar preposiciones que dependen de una variable n que toma una infinidad de valores enteros.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-38,['�cual es la diferencia entre deduccion e inducion ?'], ['la deduccion es un argumento donde la conclusion se infiere de las premisas por otra parte la induccion utiliza las premisas como apoyo para encontrar la conclusion pero no la garantiza'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-39,['�Que es una estrucura algebraica?'], ['es una n-tupla (A1,A2..An) donde A1 es un conjunto dado no vacio y {A2..An} un conjunto de operaciones aplicable a los elementos de dicho conjunto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-40,['� Que es una tupla ?'], ['es una lista ordenadade elementos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-41,['�Que es una n-tupla ?'], ['es una secuencia de n elementos siendo n un numero natural'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-42,['� Que es una 0-tupla ?'], ['es la secuencia vacia'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-43,['� Que son las leyes de composicion ?'], ['se trata de una funcion o aplicacion que toma dos elementos de 2 conjuntos dados y lo asigna a otro elemento perteneciente a uno de los 2 conjuntos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-44,['� Que son las leyes de composicion interna ?'], ['si la aplicacion que la define mantiene el mismo conjuntos tanto en el par del conjunto de partida como en el llegada'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-45,['� Que son las leyes de composicion externa ?'], ['si los conjuntos de partida son diferente entre si'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-46,['� cuales son las estructuras algebraica con una ley de composicion interna ?'], ['Magma,semigrupo,cuasigrupo,Monoide,Grupo y Grupo Abeliano'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-47,['� cuales son las estructuras algebraica con dos leyes de composicion interna?'], ['Semianillo,Anillo,Pseudoanillo,Cuerpo,Reticulo,Dominio de integridad'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-48,['�cuales son las estructuras algebraica con las leyes de composicion externa e internas','?'], ['Modulo,Espacio Vecorial y Algebra sobre un cuerpo'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-49,['Que es un magma o grupoide ?'], ['Es una estructura algebraica de la forma (A,o) donde A es un conjunto donde se ha definido una operacion binaria interna o'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-50,['� cual es la operacion interna de los magma ?'], ['para cualquier par ordenado de elementos del conjunto AxA operados por o el resultado pertenece al conjunto A'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-51,['�Que es un semigrupo ?'], ['Es una estructura algebraica de la forma (A,o) donde A es un conjunto donde se ha definido una operacion binaria interna o, se diferencia del magma porque son asociativos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-52,['� Que es un cuasigrupo ?'], ['Es una estructura algebraica similar a un grupo en el sentido de que la division es siempre posible se diferencia de los grupos por no tener propiedad','asociativa'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-53,['�como se llaman los cuasigrupo con elemento neutro?'], ['son llamados bucles'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-54,['�Que es un Monoide ?'], ['Es una estructura algebraica con una operacion binaria que es asociativa y tiene elemento neutro es decir es un semigrupo pero con elemento neutro'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-55,['� Que es un elemento neutro?'], ['Es un elemento e del conjunto tal que para cualquier otro elemento a del conjunto se cumpla:a*e=e*a=a'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-56,['�Que es la propiedad asociativa ?'], ['para cualquier elemento del conjunto no importa el orden en que se operenlas parejas de elemento siempre dara el mismo resultado'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-57,['� Que es la propiedad conmutativa ?'], ['es cuando el resultado da igual sin importar el orden ejemplo:a*b=b*a'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-58,['�Que es un grupo?'], ['Es una estructura algebraica que consta de un conjunto con una operacion que combina cualquier pareja de su elemento para formar un tercer elemento los grupos son asocitivo poseen elemento neutro y elemento inverso'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-59,['� Que es un elemento inverso ?'], ['Si tenemos un conjunto A y B pertenece a  A el elemento inverso es aquel quesi lo sumas da cero ejemplo b-b=-b+b=0'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-60,['� Que es un grupo abeliano?'], ['Es un grupo con la particulariad de que son conmutativo'],20/20,['jesus Herrera Basado en www.wikipedia.org']).



%actualizacion 2.0

	pr(0018-61,['�Que es un semianillo ?'], ['Es una estructura algebraica mas general que  un anillo posee dos leyes de composicion interna ya que es cerrada para la suma y la multiplicacion se diferencia de un anillo ya que todo elemento tiene un inverso aditivo u opuesto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-62,['� Que es un anillo?'], ['Es una estructura algebraica que es una  terna formada por un conjunto A y dos operaciones internas que son suma y multiplicacion'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-63,['� tipos de anillos ?'], ['hay dos el anillo conmutativo y el anillo unidad'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-64,['�Que es un anillo conmutativo?'], ['Es un anillo conmutativo si el producto  es conmutativo'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-65,['�Que es un anillo unidad ?'], ['Si el anillo posee un elemento neutro  para el producto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-66,['�Que es un pseudoanillo ?'], ['Es una estructura algebraica donde la suma  y multiplicacion son operaciones binarias y existe un 0 como un elemento del conjunto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).



	pr(0018-67,['� Que es un dominio de integridad ?'], ['Es un anillo que carece de elementos  divisores de cero por la izquierda y de elemento divisores por la derecha'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-68,['� Que son elementos divisores de cero ?'], ['un elemento no nulo A de un anillo es un divisor de  0 por la izquierda si existe un elemento no nulo B tal que A*B=0 los divisores por la derecha se definen analogamente'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-69,['�Que es un cuerpo?'], ['es una estructura algebraica en la cual las operaciones llamada adiccion y  multiplicacion se pueden realizar y cumplen las propiedades asociativa conmutativa y distributiva de la multiplicacion respecto a la adiccion ademas de inverso aditivo multiplicativo y de elemento neutro para la adiccion y otro para la multiplicacion.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-70,['�Que es un reticulo?'], ['es una estructura algebraica con dos operaciones binarias o bien un conjunto parcialmente ordenado con ciertas propiedades especificas.'],20/20,['jesus HerreraBasado en www.wikipedia.org']).


	pr(0018-71,['�Que son conjunto parcialmente ordenado?'], ['es un conjunto equipado con una relacion binaria de orden parcial esta  formaliza el concepto intuitivo de orden,secuencia o arreglo de los elementos del','conjunto.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-72,['�Que es un diagrama de Hasse ?'], ['es una representacion grafica simplificada de un conjunto parcialmente ordenando finito esto  se consigue eliminando informacion redundante.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-73,['�Que son los espacios vectoriales?'], ['es una estructura algebraica creada apartir de un conjunto no vacio una operacion interna ( llamada suma para los elementos del conjunto)y una externa (llamada producto por un escalar ).'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-74,['�Que es el algebra de boole ?'], ['es un conjunto con dos operaciones idempotentes conmutativa asociativa distributiva entre cuyos  terminos tiene una relacion de inclusion reflexiva antisimetrica y transitiva consistente con las operaciones y una operacion de complementacion.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


	pr(0018-75,['�Que es el triangulo de pascal?'], ['es una representacion de los coeficientes binomiales ordenados en forma triangular.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).


% actulizacion 3.0

	pr(0018-76,['�como es la funcion recursiva de fibonacci?'], ['los numeros de fibonacci quedan definidos por la ecuacion:Fn=F(n-1)+F(n-2).'],20/20,['jesus Herrera ']).

	pr(0018-77,['�Que es el teorema del binomio de newton ?'], ['es una formula que proporciona el desarrollo de la potencia n-esima de n.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-78,['�Que es un conjunto?'], ['es una coleccion de elementos considerada en si misma como un objeto los elementos de un conjunto pueden ser cualquier cosa'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-79,['� Que es un elemento en un conjunto?'], ['es unobjeto atomico que forma parte de ese conjunto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-80,['�','Que', 'es','un', 'subconjunto','?'], ['es un conjunto que esta contenido en otro conjunto ejemplo los numeros reales son un subconjunto de los numeros complejos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-81,['�Un conjunto es subconjunto de si mismo?'], ['si ya que sus elemento estan contenidos en el formandose asi una paradoja'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-82,['�Que es una paradoja?'], ['es una proposicion en apariencia falsa o que infrige el sentido comun pero no lleva a una contradiccion logica'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-83,['�cual es el principio de contradiccion?'], ['es un principio clasico de la logica segun el cual una proposicion y su negacion no pueden ser ambas verdaderas al mismo tiempo y en el mismo sentido'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-84,['�Que es la cardinalidad de un conjunto ?'], ['es el numero de elementos que estan contenido en un conjunto'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-85,['�cuando dos conjuntos son iguales ?'], ['cuando ambos poseen los mismo elementos'],20/20,['jesus Herrera Basado en www.wikipedia.org']).



%actualizacion 4.0


	pr(0018-86,['� Que es la Matematica Discreta ?'], ['es un Area de la','matematica encargada del estudio de los conjuntos discretos finitos o infinitos numerables.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-87,['�Diferencia entre la Matematica Discreta y la Matematica continua?'], ['la matematica continua se encarga del estudio de conceptos como la continuidad y el cambio continuo la matematica discreta estudia estructuras cuyos elementos pueden ser contados como los grafos y sentencias logicas.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-88,['�Que es homomorfismo?'], ['es una funcion que preserva las operaciones definidas en dichos objetos.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

        pr(0018-89,['�Que es isomorfismo?'], ['es un homomorfismo que admite un inverso el isomorfismo tambien es llamado homomorfismo biyectivo.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-90,['�cual es la importancia del isomorfismo ?'], ['el descubrimiento de un isomorfismo entre dos estrucuturas significa esencialmente que el estudio de cada una puede reducirse al de la otra lo que nos da dos puntos de vista diferentes sobre cada cuestion y suelen ser esenciales en su adecuada comprension.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

	pr(0018-91,['�Tipos de homomorfismo?'], ['son el epimorfismo, el monomorfismo,el isomorfismo, el endomorfismo y el automorfismo.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

        pr(0018-92,['�Que es epimorfismo?'], ['es un homorfismo cuya imagen coincide con el nucleo del homorfismo llamado tambien homomorfismo sobreyectivo.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

        pr(0018-93,['�Que es endomorfismo?'], ['es un homorfismo de un conjunto asi mismo.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

        pr(0018-94,['� Que es automorfismo?'], ['es un ismorfismo de un conjunto asi mismo.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).

        pr(0018-95,['�Que es una falacia?'], ['es un argumento que si bien puede ser convincete o persuasivo no es logicamente validoesto no quiere decir que el argumento falaces sea falso sino que el argumento mismo es malo no es valido.'],20/20,['jesus Herrera Basado en www.wikipedia.org']).












































































