package ve.unix.ula.mathematicaapp;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class Buscador extends AppCompatActivity  implements View.OnClickListener {
    private NuestroBuscador buscador;
    private Button Buscar;
    private EditText Consulta;
    private TextView Respuesta, Errorconsulta;
    ProgressDialog proceso;
    private DrawerLayout nav;
    private ListView navList;
    private TypedArray navIcons;
    ArrayList<String> RespuestasBuscador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscador);
        Buscar = (Button)findViewById(R.id.buscar);
        Consulta = (EditText)findViewById(R.id.Consulta);
        Respuesta = (TextView) findViewById(R.id.Respuesta);
        Errorconsulta = (TextView) findViewById(R.id.ErrorConsulta);
        Buscar.setOnClickListener(this);
        navList = (ListView) findViewById(R.id.navList);
        findViewById(R.id.buscarRapido).setOnClickListener(this);
        buscador = new NuestroBuscador();
        RespuestasBuscador = new ArrayList<>();

    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.buscarRapido){

            if(Consulta.getText().toString().isEmpty()){
                Errorconsulta.setText("Campo Vacio");
                return;
            }else{
                ArrayList<String> respuestas = new ArrayList<String>();
                String Aux = "";
                String auz[] =  new String[2];
                auz[0] = Consulta.getText().toString();
                proceso = new ProgressDialog(Buscador.this);



                proceso.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                proceso.setMessage("Buscando...");
                proceso.setCancelable(true);
                proceso.setMax(25);

                new BuscadorThread(this ,false).execute(auz);

                for(String respuesta :respuestas){
                    Aux += respuesta + "\n";
                }
                // Respuesta.setText(Aux);

            }


        }
        if(v.getId()==R.id.buscar){
            if(Consulta.getText().toString().isEmpty()){
                Errorconsulta.setText("Campo Vacio");
                return;
            }else{
                ArrayList<String> respuestas = new ArrayList<String>();
                String Aux = "";
                String auz[] =  new String[2];
                auz[0] = Consulta.getText().toString();
                proceso = new ProgressDialog(Buscador.this);



                proceso.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                proceso.setMessage("Buscando...");
                proceso.setCancelable(true);
                proceso.setMax(25);

                new BuscadorThread(this ,true).execute(auz);

                for(String respuesta :respuestas){
                    Aux += respuesta + "\n";
                }
                // Respuesta.setText(Aux);

            }
        }
    }

    public class item1 {
        String texto;
        int icono;

        public item1(String TExto, int ID) {
            texto = TExto;
            icono = ID;

        }
    }
    public class BuscadorThread extends AsyncTask<String,Integer,ArrayList<String> > implements NuestroBuscador.OnFragmentInteractionListener{
        AppCompatActivity activity;
        boolean Opcion;
        BuscadorThread(AppCompatActivity Activity, boolean opcion){
            this.activity = Activity;
            Opcion = opcion;
        }
        @Override
        protected ArrayList<String> doInBackground(String... params) {
            if(Opcion){

                return Buscador.BuscarRespuestaoPregunta(Buscador.this,params[0],true);
            }else{

                return BuscarRespuestaoPregunta(Buscador.this,params[0],true);
            }

        }
        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            proceso.setProgress(progreso);
        }

        @Override
        protected void onPreExecute() {
            proceso.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    BuscadorThread.this.cancel(true);
                }
            });
            proceso.setProgress(0);
            proceso.show();
        }
        protected void onPostExecute(ArrayList<String> result) {
                RespuestasBuscador.clear();
                String resultfinish = "";
                ArrayList<String> aux = new ArrayList<>();
                String aux1;
                for(String r:result){
                    Log.e(r, "lista");
                    if(r.contains("pr(") && r.contains(").") ) {
                        System.out.println(r);
                        aux.add(r.substring(r.indexOf('[')+1, r.indexOf(']')));
                        aux1 = r.substring(r.indexOf(']'));
                        aux1 = aux1.substring(aux1.indexOf('['), aux1.indexOf("/20"));
                        Log.e(aux1, "lista");
                        RespuestasBuscador.add(aux1.substring(aux1.indexOf('[')+1, aux1.indexOf(']')));
                    }


                }
            proceso.cancel();

            Respuesta.setText(Consulta.getText());

            navIcons = getResources().obtainTypedArray(R.array.icons);


            for(int i=0;i<result.size();i++){

            }


            ArrayList<Buscador.item1> Items = new ArrayList<Buscador.item1>();
            for (int i = 0; i < aux.size(); i++) {
                Log.e(""+i,"agregando")
                        ;
                Items.add(new Buscador.item1(aux.get(i), R.drawable.original));

            }

            Buscador.navigationAdapter adapter = new Buscador.navigationAdapter(this.activity,Items);
            navList.setAdapter(adapter);
            navList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    AlertDialog.Builder Buider = new AlertDialog.Builder(Buscador.this);
                    Buider.setMessage(RespuestasBuscador.get(position))
                            .setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });

                    Buider.create().show();


                }
            });
        }


        @Override
        public void onFragmentInteraction(Integer... values) {
            onProgressUpdate(values);
        }
    }

    private static int minimum(int a, int b, int c) {
        if(a<=b && a<=c)
        {
            return a;
        }
        if(b<=a && b<=c)
        {
            return b;
        }
        return c;
    }

    public static int computeLevenshteinDistance(String str1, String str2) {
        return computeLevenshteinDistance(str1.toCharArray(),
                str2.toCharArray());
    }

    private static int computeLevenshteinDistance(char [] str1, char [] str2) {
        int [][]distance = new int[str1.length+1][str2.length+1];

        for(int i=0;i<=str1.length;i++)
        {
            distance[i][0]=i;
        }
        for(int j=0;j<=str2.length;j++)
        {
            distance[0][j]=j;
        }
        for(int i=1;i<=str1.length;i++)
        {
            for(int j=1;j<=str2.length;j++)
            {
                distance[i][j]= minimum(distance[i-1][j]+1,
                        distance[i][j-1]+1,
                        distance[i-1][j-1]+
                                ((str1[i-1]==str2[j-1])?0:1));
            }
        }
        return distance[str1.length][str2.length];

    }
    public static String LimpiarString(String palabra){
        String Prohibidas[] = {"¿", "de ","DE ", "De ", "la " , "La ", "LA ", "el ", "El ", "EL ", "ella ", "Ella ", " ELLA ", " lo ",
                " Lo ", " LO ", " las ", " Las ", " LAS ", " ellos ", " Ellos ", " ELLOS ", " ellas ", " Ellas ", " ELLAS ",
                " cual ", " Cual ", " CUAL ", " cuales ", " Cuales ", " CUALES ", " cuál ", " Cuál ", " CUÁL ", " cuáles ",
                " Cuáles ", " CUÁLES ", "que ", " Que ", " QUE ", " qué ", " Qué ", " QUÉ ", " es ", " Es " , " Del ", " del ", " DEL ",
                " Se ", " se " , " otra " , " Otra " , " puede " , " Puede " ," Un ", " un ", " Sobre ", " sobre " ,"-"};

        palabra =palabra.replaceAll("á","a");
        palabra =palabra.replaceAll("é","e");
        palabra =palabra.replaceAll("í","i");
        palabra =palabra.replaceAll("ó","o");
        palabra =palabra.replaceAll("ú","u");

        palabra =palabra.replace('?',' ');
        for(int i=0; i < Prohibidas.length; i++){
            palabra =palabra.replaceAll( Prohibidas[i]," ");
        }

        return palabra;
    }

    public static ArrayList<String> BuscarRespuestaoPregunta(Context contex,String usuario, boolean Objetivo){

        ArrayList<String> Respuesta = new ArrayList<String>();
        ArrayList<String> Respuesta1 = new ArrayList<String>();
        ArrayList<String> Respuesta2 = new ArrayList<String>();
        try {




            Respuesta.add("No hay Respuesta");
            int distanciaTotal=500;
            int ValorDistancia=500, Distanciapalabra=0, DistanciaPr=1000 , NumerodeCoincidencias=0, NumeroMenordeConicidencias=-500;
            String pr,UsuariosTokenizados[] = LimpiarString(usuario).split(" ");
            InputStream inputStream =null;
            //inputStream = new FileInputStream( System.getProperty("user.dir") + "/prolog/0027.pl");

            for(int l=0;l<27;l++){
                System.out.println("entro en el archivo " + l);

                if(l==0)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0000);
                if(l==1)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0001);
                if(l==2)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0002);
                if(l==3)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0003);
                if(l==4)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0004);
                if(l==5)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0005);
                if(l==6)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0006);
                if(l==7)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0007);
                if(l==8)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0008);
                if(l==9)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0009);
                if(l==10)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0010);
                if(l==11)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0011);
                if(l==12)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0012);
                if(l==13)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0013);
                if(l==14)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0014);
                if(l==15)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0015);
                if(l==16)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0016);
                if(l==17)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0017);
                if(l==18)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0018);
                if(l==19)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0019);
                if(l==20)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0020);
                if(l==21)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0021);
                if(l==22)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0022);
                if(l==23)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0023);
                if(l==24)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0024);
                if(l==26)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0026);
                if(l==25)
                    inputStream = contex.getResources().openRawResource(R.raw.pr0025);
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));


                String line;

                for (int k=0;(line = reader.readLine()) != null;k++) {
                    //System.out.println("entro");
                    Distanciapalabra = 0;
                    if(line.contains("pr(") && (line.charAt(0)!='%')){
                        //System.out.println("entro1");

                        while(!line.contains("]") || !line.contains(")")){
                            line+=reader.readLine();
                        }
                        NumerodeCoincidencias=0;
                        for(int j=0;j<UsuariosTokenizados.length;j++){
                            if(line.contains(UsuariosTokenizados[j]))
                                NumerodeCoincidencias++;
                        }
                        if(NumerodeCoincidencias > NumeroMenordeConicidencias){
                            NumeroMenordeConicidencias=NumerodeCoincidencias;
                            Respuesta1.clear();
                            Respuesta1.add(line);
                        }
                        if(NumerodeCoincidencias == NumeroMenordeConicidencias){

                            if(!Respuesta1.contains(line))
                                Respuesta1.add(line);
                        }
                        //System.out.println(line);
                        String r [] = new String[0];
                      /*  if(Objetivo){
                            String aux = line.substring(line.indexOf(",")+3,line.indexOf("]")) ;
                            if(aux.split(",").length < aux.split(" ").length){
                                r = aux.split(" ");
                            }else{
                                r = aux.split(",");
                            }
                        }else{
                            System.out.println(line);
                            System.out.println(line.substring(line.indexOf(']')+1).substring(line.substring(line.indexOf(']')+1).indexOf('[')+1 ,line.substring(line.indexOf(']')+1).indexOf("],") ));

			        			/*String aux =line.substring(line.indexOf(']')+1).substring(line.substring(line.indexOf(']')+1).indexOf('[')+1 ,line.substring(line.indexOf(']')+1).indexOf(']') ) ;
			        			if(aux.split(",").length < aux.split(" ").length){
				        			r = LimpiarString(aux).split(" ");
				        		}else{
				        			r = LimpiarString(aux).split(",");
				        		}*/
                       // }
                        /*for(int j=0;j<UsuariosTokenizados.length;j++){
                            ValorDistancia = 500;
                            for(int i=0;i<r.length;i++){
                                if(!UsuariosTokenizados[j].isEmpty() && !r[i].isEmpty() ){
                                    int aux=computeLevenshteinDistance(r[i].replaceAll(" ", "").replaceAll("'",""), UsuariosTokenizados[j].replaceAll(" ",""));
                                    if(aux<ValorDistancia){
                                        ValorDistancia=aux;
                                    }
                                }
                            }

                            if(!(ValorDistancia==500)){
                                Distanciapalabra+=ValorDistancia;

                            }

                        }*/


                        /*if(Distanciapalabra < DistanciaPr){
                            DistanciaPr = Distanciapalabra;
                            if(l<10)
                                pr = System.getProperty("user.dir") + "/prolog/000"+l + ".pl";
                            else
                                pr = System.getProperty("user.dir") + "/prolog/00"+l + ".pl";
                            Respuesta.clear();
                            Respuesta.add(line);/*.substring(line.substring(line.indexOf("[") +1 ).indexOf("["),line.substring(line.substring(line.indexOf("[")).indexOf("[")).indexOf("]"))*/;

                        }
                 /*       if(Distanciapalabra == DistanciaPr && !Respuesta.contains(line)){
                            // System.out.println("Distancia = " + DistanciaPr + " Respuesta " + line );
                            Respuesta.add(line);
                        }*/




			        		/*System.out.println(line.substring(line.indexOf(",")+3,line.indexOf("]")));
			        		for(int i =0;i<r.length;i++){
			        			System.out.println( r[i]);
			        		}*/
                   // }

                }
                inputStream.close();
                reader.close();


            }
            for(String a:Respuesta1){
                System.out.println("Respuesta1="+a);
            }
            return Respuesta1;
            /*
            for(String a:Respuesta){
                if(Respuesta1.contains(a))
                    Respuesta2.add(a);
                System.out.println("Respuesta="+a);
            }
            */
           /* for(String a:Respuesta2){
                System.out.println("Respuesta2="+a);
            }*/
           /* if(Respuesta2.isEmpty())
                return Respuesta1;
            return Respuesta2;*/

            //System.out.println(out.toString() );   //Prints the string content read from input stream
        }catch (IOException error){
            System.out.println(error.getLocalizedMessage()+error.getMessage());
        }
        return Respuesta;

    }
    public class navigationAdapter extends BaseAdapter {
        private ArrayList<Buscador.item1> items;
        AppCompatActivity activity;


        public navigationAdapter(AppCompatActivity activity, ArrayList<Buscador.item1> items) {
            super();

            this.items = items;
            this.activity = activity;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Buscador.navigationAdapter.Fila view;
            LayoutInflater inflater = activity.getLayoutInflater();
            if (convertView == null) {
                view = new Buscador.navigationAdapter.Fila();
                Buscador.item1 item = items.get(position);
                convertView = inflater.inflate(R.layout.items, null);
                view.textView = (TextView) convertView.findViewById(R.id.TextItem);
                view.imageView = (ImageView) convertView.findViewById(R.id.icono);
                view.Dividir =  convertView.findViewById(R.id.dividir);
                view.textView.setText(item.texto);
                view.imageView.setImageResource(item.icono);
                convertView.setTag(view);

            } else {
                view = (Buscador.navigationAdapter.Fila) convertView.getTag();
            }
            return convertView;
        }

        public class Fila {
            ImageView imageView;
            TextView textView;
            View Dividir;
        }
    }

}
