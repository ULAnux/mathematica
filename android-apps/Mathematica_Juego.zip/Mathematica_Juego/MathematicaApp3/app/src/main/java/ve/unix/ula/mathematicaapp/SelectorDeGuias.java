package ve.unix.ula.mathematicaapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class SelectorDeGuias extends AppCompatActivity implements View.OnClickListener {
    private ImageView Logica,Conjuntos, Combinatioria,Variaciones,Permutaciones;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selector_de_guias);
        this.Logica  = (ImageView) findViewById(R.id.Logica);
        this.Combinatioria = (ImageView) findViewById(R.id.Combinatoria);
        this.Conjuntos = (ImageView) findViewById(R.id.Conjuntos);
        this.Variaciones = (ImageView)findViewById(R.id.Variaciones);
        this.Permutaciones = (ImageView)findViewById(R.id.Permutaciones);
        Logica.setOnClickListener(this);
        Conjuntos.setOnClickListener(this);
        Combinatioria.setOnClickListener(this);
        Variaciones.setOnClickListener(this);
        Permutaciones.setOnClickListener(this);
        ((ImageView)findViewById(R.id.ultimotema)).setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(SelectorDeGuias.this,Webviewer.class);
        switch (v.getId()){

            case R.id.Logica:
                intent.putExtra("Tema",1);
                startActivity(intent);
                break;
            case R.id.Conjuntos:
                    intent.putExtra("Tema", 2);
                    startActivity(intent);

                break;
            case R.id.Variaciones:

                    intent.putExtra("Tema",3);
                    startActivity(intent);

                break;
            case R.id.Combinatoria:
                    intent.putExtra("Tema",4);
                    startActivity(intent);

                break;
            case R.id.Permutaciones:

                    intent.putExtra("Tema",5);
                    startActivity(intent);

                break;
            case R.id.ultimotema:

                intent.putExtra("Tema",6);
                startActivity(intent);

                break;



        }
    }
}
