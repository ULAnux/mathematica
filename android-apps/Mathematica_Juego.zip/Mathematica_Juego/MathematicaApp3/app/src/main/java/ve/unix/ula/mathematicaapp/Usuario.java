package ve.unix.ula.mathematicaapp;


import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


/**
 * Created by mator on 03/12/16.
 */

public class Usuario implements Parcelable{
    private String NombreApellido, Correo, Usuario, Contrasena;
    private int Sexo;
    private Integer Nivel,Exp, Tema,NumeroDeSaltar,icono;

    public Usuario(Parcel in) {

        NombreApellido = in.readString();
        Usuario = in.readString();
        Contrasena = in.readString();
        Correo = in.readString();
        Sexo = in.readInt();
        Nivel = in.readInt();
        Exp = in.readInt();
        Tema = in.readInt();
        NumeroDeSaltar = in.readInt();
        icono = in.readInt();
    }
    public Usuario(String Usuario, String Contrasena, String nombreApellido, String Correo, int sexo, Integer Nivel, Integer Exp, Integer Tema, Integer numero,Integer icono) {
        this.NombreApellido = nombreApellido;
        this.Correo = Correo;
        this.Sexo = sexo;
        this.Nivel = Nivel;
        this.Exp = Exp;
        this.Usuario = Usuario;
        this.Contrasena = Contrasena;
        this.Tema = Tema;
        this.NumeroDeSaltar = numero;
        this.icono = icono;


    }
    public Usuario(String Line){
        String Aux1,Aux2;
        Aux1 = Line.substring(0, Line.indexOf(":"));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        Aux2 = Line.substring(0, Line.indexOf(":"));

        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );

        this.setUsuario(Aux1);
        this.setContrasena(Aux2);
        this.setNombreApellido(Line.substring(0, Line.indexOf(":")));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setNivel(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        System.out.println(Line);
        this.setTema(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setExp(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setNumeroDeSaltar(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setIcono(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setSexo(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setCorreo(Line);


    }
    public void LLenarDatos(String Line){
        Log.e(Line,"error");
        String Aux1,Aux2;
        Aux1 = Line.substring(0, Line.indexOf(":"));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        Aux2 = Line.substring(0, Line.indexOf(":"));

        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );

        this.setUsuario(Aux1);
        this.setContrasena(Aux2);
        this.setNombreApellido(Line.substring(0, Line.indexOf(":")));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setNivel(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        System.out.println(Line);
        this.setTema(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setExp(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setNumeroDeSaltar(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setIcono(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setSexo(new Integer(Line.substring(0, Line.indexOf(":"))));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        this.setCorreo(Line);


    }
    public Usuario(){

    }

    public static final Creator<Usuario> CREATOR = new Creator<Usuario>() {
        @Override
        public Usuario createFromParcel(Parcel in) {
            return new Usuario(in);
        }

        @Override
        public Usuario[] newArray(int size) {
            return new Usuario[size];
        }
    };

    public String getNombreApellido() {
        return this.NombreApellido;
    }

    public String getUsuario() {
        return this.Usuario;
    }

    public String getContrasena() {
        return this.Contrasena;
    }

    public String getCorreo() {
        return this.Correo;
    }

    public int getSexo(){return  this.Sexo;}

    public Integer getNivel() {
        return this.Nivel;
    }

    public Integer getExp() {
        return this.Exp;
    }
    public Integer getTema() {
        return this.Tema;
    }
    public Integer getNumeroDeSaltar() {
        return this.NumeroDeSaltar;
    }
    public Integer getIcono() {
        return this.icono;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }

    public void setNombreApellido(String Nombre) {
        this.NombreApellido = Nombre;
    }

    public void setCorreo(String correo) {
        this.Correo = correo;
    }

    public void setSexo(int sexo){this.Sexo = sexo;}

    public void setNivel(Integer nivel) {
        this.Nivel = nivel;
    }

    public void setTema(Integer Exp) {
        this.Tema = Exp;
    }
    public void setExp(Integer Exp) {
        this.Exp = Exp;
    }
    public void setNumeroDeSaltar(Integer Exp) {
        this.NumeroDeSaltar = Exp;
    }
    public void setIcono(Integer Exp) {
        this.icono = Exp;
    }

    public void writeArchivo(OutputStreamWriter Archivo) {
        try {
            Archivo.write(this.getUsuario() + ":" + this.getContrasena() + ":" + getNombreApellido() + ":" + this.getNivel()+ ":" + this.getTema() + ":" + this.getExp() +":" + this.getNumeroDeSaltar()+":" +this.getIcono() + ":" + this.getSexo() + ":" + this.getCorreo()+"\n");
            Archivo.close();
        } catch (IOException error) {
            Log.e("No Abrio El archivo", "No abrio");
        }


    }
    public void ActualizarDatos(OutputStreamWriter Archivo,ArrayList<String> Viejo){
        try {
            for (String Line:Viejo) {
                System.out.println(Line);
                Usuario aux = new Usuario(Line);
                if (this.getUsuario().equals(aux.getUsuario())  && this.getContrasena().equals(aux.getContrasena())  )
                    Archivo.write(this.toString());
                else
                    Archivo.write(Line);
            }
            Archivo.close();
        }catch (IOException error){
            Log.e(error.getLocalizedMessage(),error.getMessage());
        }


    }
    public boolean LLenarseUsuarioActivo(BufferedReader Archivo){
        try {
            String Line = Archivo.readLine();
            Log.e(Line,"error");
            if(Line.equals("Ninguno"))
                return false;
            this.LLenarDatos(Line);
            Archivo.close();
            return true;
        } catch (IOException error) {
            Log.e("No Abrio El archivo", "No abrio");
            return false;
        }

    }

    public void UsuarioActivo(OutputStreamWriter Archivo){
        try {
            Archivo.write(this.toString());
            Archivo.close();
        }catch (IOException error){
            Log.e(error.getLocalizedMessage(),error.getMessage());
        }
    }

    public void CerrarSesion(OutputStreamWriter Archivo){
        try {
            Archivo.write("Ninguno");
            Archivo.close();
        }catch (IOException error){
            Log.e(error.getLocalizedMessage(),error.getMessage());
        }
    }

    public ArrayList<String> AllUsers(BufferedReader Archivo){
        try {
            ArrayList<String> aux = new ArrayList<String>();
            for (String Line; (Line = Archivo.readLine()) != null; )
                aux.add(Line);
            Archivo.close();
            return aux;
        }catch (IOException error){
            Log.e(error.getLocalizedMessage(),error.getMessage());
            return null;
        }
    }
    public boolean escribirse(String Line, String Usuario, String Contrasena){
        String Aux1,Aux2;
        Aux1 = Line.substring(0, Line.indexOf(":"));
        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        Aux2 = Line.substring(0, Line.indexOf(":"));

        Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
        if (Aux1.equals(Usuario)  && Aux2.equals(Contrasena)) {
            this.setUsuario(Aux1);
            this.setContrasena(Aux2);
            this.setNombreApellido(Line.substring(0, Line.indexOf(":")));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setNivel(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            System.out.println(Line);
            this.setTema(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setExp(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setNumeroDeSaltar(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setIcono(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setSexo(new Integer(Line.substring(0, Line.indexOf(":"))));
            Line = Line.substring(Line.indexOf(":") + 1, Line.length() );
            this.setCorreo(Line);


            return true;

        }else{
            return false;
        }


    }

    public Boolean ReadArchivo(BufferedReader Archivo, String Usuario, String Contrasena) {
        try {

            String Line;

            for (; (Line = Archivo.readLine()) != null; ) {
                System.out.println(Line);
                if(this.escribirse(Line,Usuario,Contrasena)){
                    return true;
                }

            }
            Archivo.close();
            return false;
        } catch (IOException error) {
            Log.e("No Abrio El archivo", "No abrio");
            return false;
        }


    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(NombreApellido);
        dest.writeString(Usuario);
        dest.writeString(Contrasena);
        dest.writeString(Correo);
        dest.writeInt(Sexo);
        dest.writeInt(Nivel);
        dest.writeInt(Exp);
        dest.writeInt(Tema);
        dest.writeInt(NumeroDeSaltar);
        dest.writeInt(icono);


    }

    private void readFromParcel(Parcel in) {
        NombreApellido = in.readString();
        Usuario = in.readString();
        Contrasena = in.readString();
        Correo = in.readString();
        Sexo = in.readInt();
        Nivel = in.readInt();
        Exp = in.readInt();
        Tema= in.readInt();
        NumeroDeSaltar = in.readInt();
        icono = in.readInt();


    }
    public String toString(){
        return this.getUsuario() + ":" + this.getContrasena() + ":" + getNombreApellido() + ":" + this.getNivel()+ ":" + this.getTema() + ":" + this.getExp() +":" + this.getNumeroDeSaltar()+":" +this.getIcono() + ":" +this.getSexo() + ":" + this.getCorreo();
    }

}



