package ve.unix.ula.mathematicaapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PreguntaF.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PreguntaF#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PreguntaF extends android.support.v4.app.Fragment  {
// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private static final String ARG_PARAM1 = "param1";
private static final String ARG_PARAM2 = "param2";
private Preguntas pregunta;
private TextView textos[];
// TODO: Rename and change types of parameters
private String mParam1;
private String mParam2;
private Spinner spinner1,spinner2,spinner3,spinner4;
        int RespuestasUsuario[];

private OnFragmentInteractionListener mListener;

public PreguntaF() {
        // Required empty public constructor
        RespuestasUsuario = new int[4];
        }

/**
 * Use this factory method to create a new instance of
 * this fragment using the provided parameters.
 *
 * @param param1 Parameter 1.
 * @param param2 Parameter 2.
 * @return A new instance of fragment PreguntaF
 */
// TODO: Rename and change types and number of parameters
public static PreguntaF newInstance(String param1, String param2) {
        PreguntaF fragment = new PreguntaF();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
        }

@Override
public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        mParam1 = getArguments().getString(ARG_PARAM1);
        mParam2 = getArguments().getString(ARG_PARAM2);
        }
        }

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        View rootView  =inflater.inflate(R.layout.fragment_pregunta2, container, false);
        textos = new TextView[16];
        ((TextView)rootView.findViewById(R.id.Pregunta)).setText(pregunta.preguntas);
        textos[0] = (TextView) rootView.findViewById(R.id.valor1);
        textos[1] = (TextView) rootView.findViewById(R.id.valor2);
        textos[2] = (TextView) rootView.findViewById(R.id.valor3);
        textos[3] = (TextView) rootView.findViewById(R.id.valor4);
        textos[4] = (TextView) rootView.findViewById(R.id.valor5);
        textos[5] = (TextView) rootView.findViewById(R.id.valor6);
        textos[6] = (TextView) rootView.findViewById(R.id.valor7);
        textos[7] = (TextView) rootView.findViewById(R.id.valor8);
        textos[8] = (TextView) rootView.findViewById(R.id.valor9);
        textos[9] = (TextView) rootView.findViewById(R.id.valor10);
        textos[10] = (TextView) rootView.findViewById(R.id.valor11);
        textos[11] = (TextView) rootView.findViewById(R.id.valor12);
        textos[12] = (TextView) rootView.findViewById(R.id.valor13);
        textos[13] = (TextView) rootView.findViewById(R.id.valor14);
        textos[14] = (TextView) rootView.findViewById(R.id.valor15);
        textos[15] = (TextView) rootView.findViewById(R.id.valor16);
        Log.e("antes del loop",pregunta.toString());
        for(int i=0; i < 16; i++){
                Log.e("Loop","preguntaf" +pregunta.Opciones[i]);
                textos[i].setText(pregunta.Opciones[i]);
        }

        spinner1 = (Spinner)rootView.findViewById(R.id.Spiner1);
        spinner2 = (Spinner)rootView.findViewById(R.id.Spiner2);
        spinner3 = (Spinner)rootView.findViewById(R.id.Spiner3);
        spinner4 = (Spinner)rootView.findViewById(R.id.Spiner4);
        String[] valores = {"","Verdadero","Falso"};

        spinner1.setAdapter(new ArrayAdapter<String>(rootView.getContext(), android.R.layout.simple_spinner_item ,valores));
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
@Override
public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(pregunta.Respuesta.charAt(0) =='V'){
                if(id == 1)
                        RespuestasUsuario[0] = 1;
                else if(id == 2)
                        RespuestasUsuario[0] = 2;
                else if(id == 0)
                        RespuestasUsuario[0] = 0;
        }
        if(pregunta.Respuesta.charAt(0) =='F') {
                if (id == 2)
                        RespuestasUsuario[0] = 1;
                else if(id == 1)
                        RespuestasUsuario[0] = 2;
                else if(id == 0)
                        RespuestasUsuario[0] = 0;
        }
        int respuesta = 1;
        for(int i = 0 ; i<4;i++){
                if(RespuestasUsuario[i] == 0){
                        respuesta = 0;
                        break;
                }else if(RespuestasUsuario[i] == 2){
                        respuesta = 2;
                }
        }

        mListener.onFragmentInteraction(respuesta);

        }

@Override
public void onNothingSelected(AdapterView<?> parent) {

        }
        });
        spinner2.setAdapter(new ArrayAdapter<String>(rootView.getContext(), android.R.layout.simple_spinner_item ,valores));
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
@Override
public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(pregunta.Respuesta.charAt(2) =='V'){
                if(id == 1)
                        RespuestasUsuario[1] = 1;
                else if(id == 2)
                        RespuestasUsuario[1] = 2;
                else if(id == 0)
                        RespuestasUsuario[1] = 0;
        }
        if(pregunta.Respuesta.charAt(2) =='F') {
                if (id == 2)
                        RespuestasUsuario[1] = 1;
                else if(id == 1)
                        RespuestasUsuario[1] = 2;
                else if(id == 0)
                        RespuestasUsuario[1] = 0;
        }
        int respuesta = 1;
        for(int i = 0 ; i<4;i++){
                if(RespuestasUsuario[i] == 0){
                        respuesta = 0;
                        break;
                }else if(RespuestasUsuario[i] == 2){
                        respuesta = 2;
                }
        }

        mListener.onFragmentInteraction(respuesta);

        }

@Override
public void onNothingSelected(AdapterView<?> parent) {

        }
        });
        spinner3.setAdapter(new ArrayAdapter<String>(rootView.getContext(), android.R.layout.simple_spinner_item ,valores));
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
@Override
public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(pregunta.Respuesta.charAt(4) =='V'){
                if(id == 1)
                        RespuestasUsuario[2] = 1;
                else if(id == 2)
                        RespuestasUsuario[2] = 2;
                else if(id == 0)
                        RespuestasUsuario[2] = 0;
        }
        if(pregunta.Respuesta.charAt(4) =='F') {
                if (id == 2)
                        RespuestasUsuario[2] = 1;
                else if(id == 1)
                        RespuestasUsuario[2] = 2;
                else if(id == 0)
                        RespuestasUsuario[2] = 0;
        }
        int respuesta = 1;
        for(int i = 0 ; i<4;i++){
                if(RespuestasUsuario[i] == 0){
                        respuesta = 0;
                        break;
                }else if(RespuestasUsuario[i] == 2){
                        respuesta = 2;
                }
        }

        mListener.onFragmentInteraction(respuesta);
        }

@Override
public void onNothingSelected(AdapterView<?> parent) {

        }
        });
        spinner4.setAdapter(new ArrayAdapter<String>(rootView.getContext(), android.R.layout.simple_spinner_item ,valores));
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
@Override
public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(pregunta.Respuesta.charAt(6) =='V'){
                if(id == 1)
                        RespuestasUsuario[3] = 1;
                else if(id == 2)
                        RespuestasUsuario[3] = 2;
                else if(id == 0)
                        RespuestasUsuario[3] = 0;
        }
        if(pregunta.Respuesta.charAt(6) =='F') {
                if (id == 2)
                        RespuestasUsuario[3] = 1;
                else if(id == 1)
                        RespuestasUsuario[3] = 2;
                else if(id == 0)
                        RespuestasUsuario[3] = 0;
        }
        int respuesta = 1;
        for(int i = 0 ; i<4;i++){
                if(RespuestasUsuario[i] == 0){
                        respuesta = 0;
                        break;
                }else if(RespuestasUsuario[i] == 2){
                        respuesta = 2;
                }
        }

        mListener.onFragmentInteraction(respuesta);

        }

@Override
public void onNothingSelected(AdapterView<?> parent) {

        }
        });


        // Inflate the layout for this fragment
        return rootView;
        }

// TODO: Rename method, update argument and hook method into UI event
public void onButtonPressed(Uri uri) {
        if (mListener != null) {
        mListener.onFragmentInteraction(9);
        }
        }

@Override
public void onAttach(Context context) {
        super.onAttach(context);
        /*pregunta = new Preguntas();
        try {
                pregunta.LLenarPreguntaActiva(new BufferedReader(new InputStreamReader(context.openFileInput("preguntaActiva.txt"))));
        }catch (IOException e){

        }*/
        if (context instanceof OnFragmentInteractionListener) {
        mListener = (OnFragmentInteractionListener) context;
        } else {
        throw new RuntimeException(context.toString()
        + " must implement OnFragmentInteractionListener");
        }
        }

@Override
public void onDetach() {
        super.onDetach();
        mListener = null;
        }
        void Recibir(Preguntas pregunta){
        this.pregunta = pregunta;
        }



/**
 * This interface must be implemented by activities that contain this
 * fragment to allow an interaction in this fragment to be communicated
 * to the activity and potentially other fragments contained in that
 * activity.
 * <p>
 * See the Android Training lesson <a href=
 * "http://developer.android.com/training/basics/fragments/communicating.html"
 * >Communicating with Other Fragments</a> for more information.
 */
public interface OnFragmentInteractionListener {
    // TODO: Update argument type and name
    void onFragmentInteraction(Integer respuesta);
}

}
