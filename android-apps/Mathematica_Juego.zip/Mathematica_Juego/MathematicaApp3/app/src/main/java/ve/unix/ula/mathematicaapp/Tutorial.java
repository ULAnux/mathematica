package ve.unix.ula.mathematicaapp;

import android.app.FragmentManager;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class Tutorial extends AppCompatActivity implements fragmentTutorial.OnFragmentInteractionListener {
    ViewPagerAdapter mSectionsPagerAdapter;
    ViewPager mViewPager;

    public static Integer[] mImageIds = {
            R.drawable.tutorial1,
            R.drawable.tutorial2,
            R.drawable.tutorial3,
            R.drawable.tutorial4,
            R.drawable.tutorial5,
            R.drawable.tutorial6,
            R.drawable.tutorial7,
            R.drawable.tutorial8,
            R.drawable.tutorial9,
            R.drawable.tutorial10,
            R.drawable.tutorial11,
            R.drawable.tutorial12,
            R.drawable.tutorial13

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);
        getSupportActionBar().hide();
        mSectionsPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.pager);
        for(int i = 0 ;i<mImageIds.length;i++){
            mSectionsPagerAdapter.addFragment(fragmentTutorial.newInstance(""+i,mImageIds[i]));
        }



        mViewPager.setAdapter(mSectionsPagerAdapter);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void Termino() {
        findViewById(R.id.Siguiete).setVisibility(View.VISIBLE);
        findViewById(R.id.Siguiete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Menu_opciones.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }

    public class ViewPagerAdapter extends FragmentPagerAdapter {
        List<fragmentTutorial> fragments; //acá voy a guardar los fragments

        //constructor
        public ViewPagerAdapter(android.support.v4.app.FragmentManager fm) {
            super(fm);
            fragments = new ArrayList<fragmentTutorial>();
        }

        @Override
        public fragmentTutorial getItem(int position) {
            //return PlaceholderFragment.newInstance(position + 1);
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            //return 3;
            return this.fragments.size();
        }

        public void addFragment(fragmentTutorial xfragment){
            this.fragments.add(xfragment);
        }
    }
}
