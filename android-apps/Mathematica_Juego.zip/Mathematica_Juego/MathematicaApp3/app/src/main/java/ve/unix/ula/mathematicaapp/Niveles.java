package ve.unix.ula.mathematicaapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Niveles extends AppCompatActivity implements View.OnClickListener{
    ImageView Level1,Level2,Level3;
    TextView level1,level2,level3;
    private Usuario user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_niveles);
        user = new Usuario();
        try {
            if(!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt"))))) {
                Intent intent =new Intent(getApplicationContext(),Login.class);
                startActivity(intent);
                finish();
            }

        }catch (IOException Error){
            Log.e(Error.getMessage(),Error.getMessage());
        }
        Level1 = (ImageView) findViewById(R.id.level1);
        Level2 = (ImageView) findViewById(R.id.level2);
        Level3 = (ImageView) findViewById(R.id.level3);
        level1 = (TextView) findViewById(R.id.Level1);
        level2 = (TextView) findViewById(R.id.Level2);
        level3 = (TextView) findViewById(R.id.Level3);
        Level1.setOnClickListener(this);
        Level2.setOnClickListener(this);
        Level3.setOnClickListener(this);

            if (getIntent().getExtras().getInt("Tema")==1) {
                level1.setText("Conceptos de lógica, proposición y ejercicios.");
                level2.setText("Concepto de argumento y ejercicios.");
                Level3.setVisibility(View.INVISIBLE);
                level3.setVisibility(View.INVISIBLE);
                if(user.getNivel()==1) {
                    Level1.setImageResource(R.drawable.logicacolor1);
                    Level2.setImageResource(R.drawable.logicagris2);

                }else{
                    Level1.setImageResource(R.drawable.logicacolor1);
                    Level2.setImageResource(R.drawable.logicacolor2);
                }

            }
            if (getIntent().getExtras().getInt("Tema")==2) {
                level1.setText("Concepto de conjunto, subconjunto, pertenencia, igualdad de conjuntos, conjunto vacío y conjunto universal.");
                level2.setText("Unión de conjuntos, intersección de conjuntos, diferencia de conjuntos, complemento de un conjunto");
                level3.setText("Concepto de par ordenado, producto cartesiano, función, tipos de funciones.");
                if(user.getNivel()==1) {
                    Level1.setImageResource(R.drawable.conjuntocolor);
                    Level2.setImageResource(R.drawable.conjuntogris1);
                    Level3.setImageResource(R.drawable.conjuntogris3);

                }else if(user.getNivel()==2){
                    Level1.setImageResource(R.drawable.conjuntocolor);
                    Level2.setImageResource(R.drawable.conjuntocolor1);
                    Level3.setImageResource(R.drawable.conjuntogris3);
                }else{
                    Level1.setImageResource(R.drawable.conjuntocolor);
                    Level2.setImageResource(R.drawable.conjuntocolor1);
                    Level3.setImageResource(R.drawable.conjuntocolor3);
                }

            }
            if (getIntent().getExtras().getInt("Tema")==3) {
                level1.setText("Concepto de estructura algebráica, conjunto, álgebra de Boole, leyes de composición, grupo.");
                level2.setText(" Concepto de anillos, tipos de anillos, cuerpo, ley de composición externa.");
                Level3.setVisibility(View.INVISIBLE);
                level3.setVisibility(View.INVISIBLE);
                if(user.getNivel()==1) {
                    Level1.setImageResource(R.drawable.estructuracolor1);
                    Level2.setImageResource(R.drawable.estructuragris2);

                }else{

                    Level1.setImageResource(R.drawable.estructuracolor1);
                    Level2.setImageResource(R.drawable.estructuracolor2);
                }

            }
        if (getIntent().getExtras().getInt("Tema")==4) {
            level1.setText("Concepto de Variaciones, variaciones con repetición y ejercicios.");
            level2.setText("Concepto de combinatoria, principio de multiplicación y ejercicios.");
            level3.setText("Concepto de permutación, factorial y ejercicios.");
            if(user.getNivel()==1) {
                Level1.setImageResource(R.drawable.combinatoria1color);
                Level2.setImageResource(R.drawable.combinatoria2gris);
                Level3.setImageResource(R.drawable.combinatoria3gris);

            }else if(user.getNivel()==2){
                Level1.setImageResource(R.drawable.combinatoria1color);
                Level2.setImageResource(R.drawable.combinatoria2color);
                Level3.setImageResource(R.drawable.combinatoria3gris);
            }else{
                Level1.setImageResource(R.drawable.combinatoria1color);
                Level2.setImageResource(R.drawable.combinatoria2color);
                Level3.setImageResource(R.drawable.combinatoria3color);
            }

        }
        if (getIntent().getExtras().getInt("Tema")==4) {
            level1.setText("Concepto de Inducción matemática, recurrencia y ejercicios.");
            level2.setText("Numeros especiales, la serie fibbonaci y ejercicios.");
            level3.setText("Concepto de complejidad computacinal, tiempo de ejecucion y ejercicios.");
            if(user.getNivel()==1) {
                Level1.setImageResource(R.drawable.induccionmatcolor);
                Level2.setImageResource(R.drawable.inducgris);
                Level3.setImageResource(R.drawable.recurrenciagris);

            }else if(user.getNivel()==2){
                Level1.setImageResource(R.drawable.induccionmatcolor);
                Level2.setImageResource(R.drawable.induccioncolor);
                Level3.setImageResource(R.drawable.recurrenciagris);
            }else{
                Level1.setImageResource(R.drawable.induccionmatcolor);
                Level2.setImageResource(R.drawable.induccioncolor);
                Level3.setImageResource(R.drawable.recurrenciacolor);
            }

        }




    }

    @Override
    public void onClick(View v) {
        Log.e("Niveles","entro");
        Intent intent = new Intent(getApplicationContext(),Test.class);
        intent.putExtra("Tema",getIntent().getExtras().getInt("Tema"));
        Intent data = new Intent();
        setResult(RESULT_OK,  data);
        switch (v.getId()){
            case R.id.level1:
                intent.putExtra("nivel",1);
                startActivity(intent);
                finish();
                break;
            case R.id.level2:
                if(user.getNivel() >= 2) {
                    intent.putExtra("nivel", 2);
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(Niveles.this,"No has llegado a este nivel todavía.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.level3:
                if(user.getNivel() == 3) {
                    intent.putExtra("nivel",3);
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(Niveles.this,"No has llegado a este nivel todavía.",Toast.LENGTH_SHORT).show();
                }

                break;


        }

    }
}


