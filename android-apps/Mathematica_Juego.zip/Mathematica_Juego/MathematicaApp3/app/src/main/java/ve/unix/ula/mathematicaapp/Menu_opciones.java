package ve.unix.ula.mathematicaapp;



import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleExpandableListAdapter;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.GenericArrayType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Menu_opciones extends AppCompatActivity implements frament_Juego.OnFragmentInteractionListener ,frament_Tienda.OnFragmentInteractionListener, Fragment_Usuario.OnFragmentInteractionListener,NivelSuperado.OnFragmentInteractionListener {

    private Usuario user;
    private Fragment_Usuario fragmenUsuario = new Fragment_Usuario();
    private frament_Tienda fragmentTienda = new frament_Tienda();
    private frament_Juego fragmenJuego = new frament_Juego();
    private DrawerLayout nav;
    private ListView navList;
    private TypedArray navIcons;
    View head;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.activity_menu_opciones);
        super.onCreate(savedInstanceState);
        this.user = new Usuario();
        Log.e("menu", "entro");
        try {
            if (!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt"))))) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);

            }

        } catch (IOException Error) {
            Log.e(Error.getMessage(), Error.getMessage());
        }
        nav = (DrawerLayout) findViewById(R.id.nav);
        navList = (ListView) findViewById(R.id.navList);

        head = getLayoutInflater().inflate(R.layout.header, null);
        ((TextView) head.findViewById(R.id.UserName)).setText(user.getUsuario());
        if(user.getSexo() == 1){
            if(user.getIcono() == 0){
                ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepredetermiado);
            }
        }
        if(user.getSexo() == 0){
            if(user.getIcono() == 0){
                ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpredeterminado);
            }
        }
        if(user.getIcono() == 1){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga1);
        }
        if(user.getIcono() == 2){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga2);
        }
        if(user.getIcono() == 3){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga3);
        }
        if(user.getIcono() == 4){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago1);
        }
        if(user.getIcono() == 5){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago2);
        }
        if(user.getIcono() == 6){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago3);
        }


        navList.addHeaderView(head);

        navIcons = getResources().obtainTypedArray(R.array.icons);
        String[] text = {"Nombre: " +user.getNombreApellido(),"Correo: " +user.getCorreo(), "Tema Actual: " + user.getTema(), "Nivel Actual: " + user.getNivel(), "Puntaje Actual: " + user.getExp() + " exp.", "Numero de bonus del salto: " + user.getNumeroDeSaltar() , "Acerca de nosotros","Buscar", "Guias", "Tutorial", "Cerrar sesión"};


        ArrayList<item1> Items = new ArrayList<item1>();
        for (int i = 0; i < text.length; i++) {
            Items.add(new item1(text[i], navIcons.getResourceId(i, -1)));

        }

        navigationAdapter adapter = new navigationAdapter(this, Items);
        navList.setAdapter(adapter);
        navList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e(""+position,"clicjmenu");

                            if(position==10){
                                Intent intent = new Intent(getApplicationContext(), Tutorial.class);
                                startActivity(intent);

                            }

                            if(position == 11){
                                AlertDialog.Builder Buider = new AlertDialog.Builder(Menu_opciones.this);
                                Buider.setMessage("Quieres cerrar sesión?")
                                        .setCancelable(false)
                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                            }
                                        })
                                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                try {
                                                    user.CerrarSesion(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                                    Intent intent = new Intent(getApplicationContext(), Login.class);
                                                    startActivity(intent);
                                                    finish();
                                                } catch (IOException Error) {
                                                    Log.e(Error.getMessage(), Error.getMessage());
                                                }

                                            }
                                        });

                                Buider.create().show();
                            }



                        if( position ==7) {
                            Intent intent = new Intent(getApplicationContext(), Nosotros.class);
                            startActivity(intent);
                        }


                        if( position ==9) {
                            Intent intent = new Intent(getApplicationContext(), SelectorDeGuias.class);
                            startActivity(intent);
                        }


                        if( position ==8) {
                            Intent intent = new Intent(getApplicationContext(), Buscador.class);
                            startActivity(intent);
                        }

            }
        });



        Log.i("Usuario", user.toString());
        Bundle Usuarios = new Bundle();
        Usuarios.putParcelable("usuarios", user);
        fragmenUsuario.Recibir(user);
        fragmenJuego.Recibir(user);
        fragmentTienda.Recibir(user);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("entro en fab", "otro boton");

                Intent intent = new Intent(getApplicationContext(), Buscador.class);
                startActivity(intent);
            }
        });
        TabLayout tabs = (TabLayout) findViewById(R.id.tabs);
        ViewPager pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(new SectionPagerAdapter(getSupportFragmentManager()));
        tabs.setupWithViewPager(pager);


    }

    @Override
    public void onFragmentInteraction(Uri uri) {
        Log.d("fragmento ", "aqui pasao algo " + uri.toString());
    }

    @Override
    public void ActualizaUsuarios(Usuario usuarios) {
        try {
            if (!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt"))))) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);

            }

        } catch (IOException Error) {
            Log.e(Error.getMessage(), Error.getMessage());
        }

        //View head = getLayoutInflater().inflate(R.layout.header, null);
        ((TextView) head.findViewById(R.id.UserName)).setText(user.getUsuario());
        if(user.getSexo() == 1){
            if(user.getIcono() == 0){
                ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepredetermiado);
            }
        }
        if(user.getSexo() == 0){
            if(user.getIcono() == 0){
                ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpredeterminado);
            }
        }

        if(user.getIcono() == 1){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga1);
        }
        if(user.getIcono() == 2){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga2);
        }
        if(user.getIcono() == 3){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.mujerpaga3);
        }
        if(user.getIcono() == 4){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago1);
        }
        if(user.getIcono() == 5){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago2);
        }
        if(user.getIcono() == 6){
            ((ImageView) head.findViewById(R.id.iconos)).setImageResource(R.mipmap.hombrepago3);
        }
        //navList.removeHeaderView()
        //navList.addHeaderView(head);

        navIcons = getResources().obtainTypedArray(R.array.icons);
        String[] text = {"Nombre: " +user.getNombreApellido(),"Correo: " +user.getCorreo(), "Tema Actual: " + user.getTema(), "Nivel Actual: " + user.getNivel(), "Puntaje Actual: " + user.getExp() + " exp.", "Numero de bonus del salto: " + user.getNumeroDeSaltar() ,"Buscar", "Guias","Tutorial", "Cerrar sesión"};


        ArrayList<item1> Items = new ArrayList<item1>();
        for (int i = 0; i < text.length; i++) {
            Items.add(new item1(text[i], navIcons.getResourceId(i, -1)));

        }

        navigationAdapter adapter = new navigationAdapter(this, Items);
        navList.setAdapter(adapter);
        navList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                    if(position==10){
                        Intent intent = new Intent(getApplicationContext(), Tutorial.class);
                        startActivity(intent);

                    }

                    if(position == 11){
                        AlertDialog.Builder Buider = new AlertDialog.Builder(Menu_opciones.this);
                        Buider.setMessage("Quieres cerrar sesión?")
                                .setCancelable(false)
                                .setNegativeButton("Mo", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                })
                                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            user.CerrarSesion(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                            Intent intent = new Intent(getApplicationContext(), Login.class);
                                            startActivity(intent);
                                            finish();
                                        } catch (IOException Error) {
                                            Log.e(Error.getMessage(), Error.getMessage());
                                        }

                                    }
                                });

                        Buider.create().show();
                    }


                if( position ==7) {
                    Intent intent = new Intent(getApplicationContext(), Nosotros.class);
                    startActivity(intent);
                }


                if( position ==9) {
                    Intent intent = new Intent(getApplicationContext(), SelectorDeGuias.class);
                    startActivity(intent);
                }


                if( position ==8) {
                    Intent intent = new Intent(getApplicationContext(), Buscador.class);
                    startActivity(intent);
                }

            }
        });
    }

    @Override
    public void onFragmentInteraction(Usuario usuario) {
        finish();
    }
    public void onBackPressed() {
        AlertDialog.Builder Buider = new AlertDialog.Builder(Menu_opciones.this);
        Buider.setMessage("Quiere Salir de la Aplicacion?")
                .setCancelable(false)
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        Buider.create().show();
    }

    public class SectionPagerAdapter extends FragmentPagerAdapter {

        public SectionPagerAdapter(android.support.v4.app.FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Bundle Usuarios = new Bundle();
            Usuarios.putParcelable("usuarios", user);
            switch (position) {
                case 0:
                    fragmenJuego.setArguments(Usuarios);
                    return fragmenJuego;
                case 1:
                    fragmentTienda.setArguments(Usuarios);
                    return fragmentTienda;
                default:
                    fragmenJuego.setArguments(Usuarios);
                    return fragmenJuego;
            }
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Mathematica";
                case 1:
                    return "Tienda";
                default:
                    return "Mathematica";
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu) {
            AlertDialog.Builder Buider = new AlertDialog.Builder(Menu_opciones.this);
            Buider.setMessage("Quieres cerrar sesión?")
                    .setCancelable(false)
                    .setNegativeButton("no", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setPositiveButton("si", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                user.CerrarSesion(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                Intent intent = new Intent(getApplicationContext(), Login.class);
                                startActivity(intent);
                                finish();
                            } catch (IOException Error) {
                                Log.e(Error.getMessage(), Error.getMessage());
                            }

                        }
                    });

            Buider.create().show();
        }
        if (id == R.id.nosotros) {
            Intent intent = new Intent(getApplicationContext(), Nosotros.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);

    }

    public class item1 {
        String texto;
        int icono;

        public item1(String TExto, int ID) {
            texto = TExto;
            icono = ID;

        }
    }


    public class navigationAdapter extends BaseAdapter {
        private ArrayList<item1> items;
        AppCompatActivity activity;


        public navigationAdapter(AppCompatActivity activity, ArrayList<item1> items) {
            super();

            this.items = items;
            this.activity = activity;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Fila view;
            LayoutInflater inflater = activity.getLayoutInflater();
            if (convertView == null) {
                view = new Fila();
                item1 item = items.get(position);
                convertView = inflater.inflate(R.layout.items, null);
                view.textView = (TextView) convertView.findViewById(R.id.TextItem);
                view.imageView = (ImageView) convertView.findViewById(R.id.icono);
                view.Dividir =  convertView.findViewById(R.id.dividir);

                if (item.texto.equals("Acerca de nosotros")) {
                    view.Dividir.setVisibility(View.VISIBLE);

                }
                if (item.texto.equals("Tutorial")) {
                    view.Dividir.setVisibility(View.VISIBLE);

                }
                if (item.texto.equals("Buscar")) {
                    view.Dividir.setVisibility(View.VISIBLE);

                }
                if (item.texto.equals("Cerrar sesión")) {
                    view.Dividir.setVisibility(View.VISIBLE);


                }
                if (item.texto.equals("Guias")) {
                    view.Dividir.setVisibility(View.VISIBLE);


                }
                view.textView.setText(item.texto);
                view.imageView.setImageResource(item.icono);
                convertView.setTag(view);

            } else {
                view = (Fila) convertView.getTag();
            }
            return convertView;
        }

        public class Fila {
            ImageView imageView;
            TextView textView;
            View Dividir;
        }
    }



}

