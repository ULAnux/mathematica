:- [lexer].

buscar_resp(Consulta, Respuestas) :-
  atom_codes(Consulta, ConsultaP),
  tokenizar_pregunta(ConsultaP, C),
  recuperar(C, Respuestas).

recuperar(C,Respuestas) :-
  filtrar(C, Descriptores),
  findall(R, similar(Descriptores, R), Respuestas).

similar(Consulta, Respuesta) :-
  clause(pr(_, Pregunta, Respuesta, _, _), _Body),
  ( contenida_en(Consulta, Pregunta) ;
    contenida_en(Pregunta, Consulta) ).

falta_algun(Lista1, Lista2) :-
  en(X, Lista1),
  not(en(X, Lista2)).

contenida_en(Lista1, Lista2) :-
  not(falta_algun(Lista1, Lista2)).

en(E, C) :- member(E, C).
en(E, C) :- subcadena(E, C).

subcadena(_P, []) :- false.
subcadena(P, [C|_Rest] ) :-  atom(C), atom(P),
  sub_atom(C, _, _, _, P).
subcadena(P, [_|Rest] ) :- subcadena(P, Rest).

% test

prueba_filtro :- filtrar([a, que, b], [a, b]).

filtrar([], []).
filtrar([P|R], RR) :-
  lista_negra(ListaNegra), member(P, ListaNegra), filtrar(R, RR).
filtrar([P|R], [P|RR]) :-  filtrar(R, RR).

lista_negra([que, de, qué, cuáles, cuál, cómo, es, el, la, los, las]).

tokenizar_pregunta(P, Pr) :- lex(Pr, P, []).

% tests
test1 :- buscar_resp('de que color es el caballo de Simón', [[blanco]]) .