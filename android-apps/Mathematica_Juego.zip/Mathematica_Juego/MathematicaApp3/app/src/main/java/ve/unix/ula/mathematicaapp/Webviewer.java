package ve.unix.ula.mathematicaapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Webviewer extends AppCompatActivity {
    WebView webviewer ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webviewer);
        webviewer = (WebView) findViewById(R.id.web);
        int Tema = getIntent().getExtras().getInt("Tema");
        if(Tema == 1){
            webviewer.loadUrl("file:///android_asset/guias/logica/index.html");
        }
        if(Tema == 2){
            webviewer.loadUrl("file:///android_asset/guias/Pag-Hebero/Mathematicas/guia_conjuntos.html");
        }
        if(Tema == 3){
            webviewer.loadUrl("file:///android_asset/guias/EstructurasAlgebráicas/index.html");
        }
        if(Tema == 4){
            webviewer.loadUrl("file:///android_asset/guias/Adelanto-Pag/MatCombinatoria.html");
        }
        if(Tema == 5){
            webviewer.loadUrl("file:///android_asset/guias/induccion/index.html");
        }
        if(Tema == 6){
            webviewer.loadUrl("file:///android_asset/guias/Complejidad/index.html");
        }


    }
}
