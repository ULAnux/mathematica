package Windows;
import org.jpl7.*;

import java.awt.Color;

import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;

public class PruebaJPLWindows {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public PruebaJPLWindows() {
		initialize();
	}
	public void setVisible(boolean estado){
		frame.setVisible(estado);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//System.load(System.getProperty("user.dir") +"/lib/swi-prolog/lib/i386/libjpl.so");
		frame = new JFrame();
		frame.setBackground(Color.BLACK);
		frame.setTitle("Buscador");
		frame.setMaximizedBounds(new Rectangle(500,200,300,400));
		frame.setBounds(500, 200, 1920, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(2, 1, 0, 0));
		this.frame.getContentPane().setBackground(Color.WHITE);
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		
		frame.getContentPane().setBackground(Color.yellow);
		frame.getContentPane().add(panel_1);
		frame.getContentPane().setBackground(new java.awt.Color(255, 0, 0));
		panel_1.setLayout(new GridLayout(2, 2, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Introduzca la pregunta.");
		lblNewLabel.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.DARK_GRAY);
		panel_1.add(panel_2);
		panel_2.setLayout(new GridLayout(3, 1, 0, 0));
		
		JLabel label = new JLabel("");
		panel_2.add(label);
		
		textField = new JTextField();
		textField.setBackground(Color.LIGHT_GRAY);
		panel_2.add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("");
		panel_2.add(label_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.DARK_GRAY);
		panel_1.add(panel_3);
		panel_3.setLayout(new GridLayout(3, 1, 0, 0));
		
		JButton btnNewButton = new JButton("Consultar");
		btnNewButton.setForeground(Color.DARK_GRAY);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		panel_3.add(btnNewButton);
		
		
		JLabel label_3 = new JLabel("");
		label_3.setForeground(Color.WHITE);
		panel_3.add(label_3);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.WHITE);
		panel.setBackground(Color.DARK_GRAY);
		panel.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Respuesta", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		frame.getContentPane().add(panel);
		
		JTextArea textArea = new JTextArea();
		textArea.setForeground(Color.WHITE);
		textArea.setBackground(Color.DARK_GRAY);
		panel.add(textArea);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					if(textField.getText().isEmpty()){
						textArea.setText("Por favor ingrese su consulta");
						return;
					}
					System.out.println();
					String t1 = "consult('"+System.getProperty("user.dir")+"/Prolog/mathematica.pl').";
					Query q1 = new Query(t1);
					//System.out.println( t1 + " " + (q1.hasSolution() ? "succeeded" : "failed") );
					q1.hasSolution();
					String t2 = "consult('"+System.getProperty("user.dir")+"/Prolog/buscador.pl').";
					Query q2 = new Query(t2);
					q2.hasSolution();
					//System.out.println( t2 + " is " + (q2.hasSolution() ? "succeeded" : "not provable") );
					
					//--------------------------------------------------
					String t3 = "buscar_resp('"  +textField.getText() +   "', X).";
					Query q3 = new Query(t3);
					
					Map<String, Term>[] ss4 =  q3.allSolutions();
					//System.out.println(ss4.toString());
					String Respuesta="";
					for (int i = 0; i < ss4.length; i++) {
						Iterator it = ss4[i].entrySet().iterator();
						while(it.hasNext()){
							Object key= it.next();
							//System.out.println(i + ss4[i].toString().replace('[', ' ').replace(']',' ').replace('(',' ').replace('|',' ').replace('}',' ').replace('{',' ').replace(')', 'x'));
								String aux[]= ss4[i].toString().replace('[', ' ').replace(']',' ').replace('(',' ').replaceAll("'"," ").replace('|',' ').replace('}',' ').replace('{',' ').replace(')', 'x').split("x,");
								for(int k=0; k < aux.length;k++){
									if(!aux[k].contains("  ,  ") && !aux[k].contains("xx") && !aux[k].contains("_") &&  !aux[k].contains("intersectado") && !aux[k].contains("unido") && !aux[k].contains("complemeto") && !aux[k].isEmpty())
										Respuesta = aux[k];
										//System.out.println(k+ Respuesta);
								}
						}
					}
					//Iterator it = ss4[0].entrySet().iterator();
					//Respuesta = ss4[0].toString().replaceAll(",", "\n").replace('[', ' ').replace(']',' ').replace('(',' ').replace(')',' ').replaceAll("'"," ").replace('|',' ').replace('}',' ').replaceAll(" ", "" );
					if(Respuesta.contains("_") || Respuesta.isEmpty() ){
						textArea.setText("No hay respuesta");
						return;
					}
					textArea.setText(Respuesta);
					
				}catch (PrologException error) {
					System.out.println(error.getMessage() + error.getLocalizedMessage());
					textArea.setText("error prolog");
				}catch(UnsatisfiedLinkError error){
					System.out.println(error.getMessage() + error.getLocalizedMessage());
					textArea.setText("error jpl");
				}
				
			}
		});
		
	}

}