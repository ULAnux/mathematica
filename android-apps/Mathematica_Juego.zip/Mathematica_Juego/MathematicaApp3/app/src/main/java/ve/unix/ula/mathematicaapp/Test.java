package ve.unix.ula.mathematicaapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Test extends FragmentActivity implements Pregunta.OnFragmentInteractionListener,PreguntatipoC.OnFragmentInteractionListener,PreguntaF.OnFragmentInteractionListener{

    Usuario user;
    Preguntas preguntas[];
    ImageView Siguiente;
    FragmentManager FM;
    FragmentTransaction FT;
    int estadopregunta= 0;
    int NumeroDepreguntas;
    int NivelJugando, TemaJugando;
    int NumeroVidas = 2;
    ProgressBar progressBar ;
    Context co ;

    int i = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        FM = getSupportFragmentManager();
        FT = FM.beginTransaction();
        co= getApplicationContext();
        NivelJugando = getIntent().getExtras().getInt("nivel");
        TemaJugando = getIntent().getExtras().getInt("Tema");

        Siguiente = (ImageView) findViewById(R.id.Siguiete);
        try{
            try {
                user = new Usuario();
                if(!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt"))))) {
                    Intent intent =new Intent(getApplicationContext(),Login.class);
                    startActivity(intent);
                    finish();
                }

            }catch (IOException Error){
                Log.e(Error.getMessage(),Error.getMessage());
            }

            BufferedReader Archivo = new BufferedReader(new InputStreamReader(getResources().openRawResource(R.raw.preguntasjuego)));
            NumeroDepreguntas = 0 ;
            if(TemaJugando == 1) {
                if(NivelJugando==1)
                    NumeroDepreguntas=14;
                if(NivelJugando==2)
                    NumeroDepreguntas=13;

            }else if(TemaJugando == 2) {
                if(NivelJugando==1)
                    NumeroDepreguntas=13;
                if(NivelJugando==2)
                    NumeroDepreguntas=13;
                if(NivelJugando==3)
                    NumeroDepreguntas=13;

            }else if(TemaJugando == 3) {
                if(NivelJugando==1)
                    NumeroDepreguntas=17;
                if(NivelJugando==2)
                    NumeroDepreguntas=13;


            }else if(TemaJugando == 4) {
                if(NivelJugando==1)
                    NumeroDepreguntas=12;
                if(NivelJugando==2)
                    NumeroDepreguntas=22;
                if(NivelJugando==3)
                    NumeroDepreguntas= 15;

            }else if(TemaJugando == 5) {
                if(NivelJugando==1)
                    NumeroDepreguntas=12;
                if(NivelJugando==2)
                    NumeroDepreguntas=12;
                if(NivelJugando==3)
                    NumeroDepreguntas= 14;

            }
            progressBar = (ProgressBar)findViewById(R.id.progressBar);
            progressBar.setMax(NumeroDepreguntas-2);
            preguntas = new Preguntas[NumeroDepreguntas];
            System.out.println(TemaJugando);
            System.out.println(NivelJugando);
            String Line;
            for(int i = 0, j= 0;(Line=Archivo.readLine())!=null && j<NumeroDepreguntas-1;){
                if(Line.contains("pr") && !Line.contains("%")) {
                    if(TemaJugando == 1) {
                        if(NivelJugando==1) {
                            if (i < NumeroDepreguntas-1) {
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        }
                        if(NivelJugando==2) {

                            if (i - 12 > 0 ) {
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        }

                    }
                    if(TemaJugando == 2) {
                        if(NivelJugando==1) {
                            if (i - 24 > 0) {
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        }
                        if(NivelJugando==2) {
                            if (i - 36 > 0) {
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        }
                        if(NivelJugando==3) {
                            if (i - 48 >0) {
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        }
                    }
                    if(TemaJugando == 3) {
                        if(NivelJugando==1)
                            if(i-60>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }

                        if(NivelJugando==2)
                            if(i-76>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }


                    }
                    if(TemaJugando == 4) {
                        if(NivelJugando==1)
                            if(i-88>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        if(NivelJugando==2)
                            if(i-99>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }

                        if(NivelJugando==3)
                            if(i-120>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }


                    }
                    if(TemaJugando == 5) {
                        if(NivelJugando==1)
                            if(i-134>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        if(NivelJugando==2)
                            if(i-145>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }
                        if(NivelJugando==3)
                            if(i-156>0){
                                preguntas[j] = new Preguntas(Line);
                                j++;
                            }


                    }
                    i++;
                }

            }


        }catch (IOException error){
            Log.e("Test","error Archivo");
        }
        Log.e("Test","salio del test");
        estadopregunta= 0;
        ((TextView)findViewById(R.id.Numerodepregunta)).setText("Pregunta N° 1");
        try {
            preguntas[0].PreguntaActiva(new OutputStreamWriter(openFileOutput("preguntaActiva.txt",MODE_PRIVATE)));
        }catch (IOException error){

        }
        if(preguntas[0].tipo.equals("c") ){
            Siguiente.setImageResource(R.drawable.button_calificargris);
            PreguntatipoC pregunta = new PreguntatipoC();
            pregunta.Recibir(preguntas[0]);

            Log.e("Test", "entro en click" + i);
            FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
            i++;
        }else if(preguntas[0].tipo.equals("f")){
            Siguiente.setImageResource(R.drawable.button_calificargris);
            PreguntaF pregunta = new PreguntaF();
            pregunta.Recibir(preguntas[0]);

            Log.e("Test", "entro en click" + i);
            FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
            i++;
        }else{
            Siguiente.setImageResource(R.drawable.button_calificargris);
            Pregunta pregunta = new Pregunta();
            pregunta.Recibir(preguntas[0]);

            Log.e("Test", "entro en click" + i);
            FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
            i++;
        }
        Log.e("test","entro");
        ((ImageView)findViewById(R.id.NextLevel)).setImageResource(R.drawable.button_siguientecolor);
        ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
        ((ImageView)findViewById(R.id.NextLevel)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.incrementProgressBy(1);

                try {
                    preguntas[i].PreguntaActiva(new OutputStreamWriter(openFileOutput("preguntaActiva.txt",MODE_PRIVATE)));
                }catch (IOException error){

                }

                if(preguntas[i].tipo.equals("c") ){
                    ((TextView) findViewById(R.id.Error)).setText("");
                    ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                    Siguiente.setVisibility(View.VISIBLE);
                    ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                    Siguiente.setImageResource(R.drawable.button_calificargris);
                    estadopregunta= 0;
                    PreguntatipoC pregunta = new PreguntatipoC();
                    pregunta.Recibir(preguntas[i]);

                    Log.e("Test", "entro en click" + i);
                    FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                    i++;
                }else if(preguntas[i].tipo.equals("f")){
                    ((TextView) findViewById(R.id.Error)).setText("");
                    ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                    Siguiente.setVisibility(View.VISIBLE);
                    ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                    Siguiente.setImageResource(R.drawable.button_calificargris);
                    estadopregunta= 0;
                    PreguntaF pregunta = new PreguntaF();
                    pregunta.Recibir(preguntas[i]);

                    Log.e("Test", "entro en click" + i);
                    FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                    i++;
                }else{
                    ((TextView) findViewById(R.id.Error)).setText("");
                    ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                    Siguiente.setVisibility(View.VISIBLE);
                    ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                    Siguiente.setImageResource(R.drawable.button_calificargris);
                    estadopregunta= 0;
                    Pregunta pregunta = new Pregunta();
                    pregunta.Recibir(preguntas[i]);

                    Log.e("Test", "entro en click" + i);
                    FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                    i++;
                }
            }
        });

        Siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if (v.getId() == R.id.Siguiete) {
                        Log.e("Click" +R.id.Siguiete,"entro" +v.getId());


                        ((TextView)findViewById(R.id.Numerodepregunta)).setText("Pregunta N° " +i);
                        if (estadopregunta == 1) {
                            ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.VISIBLE);
                            ((ImageView) findViewById(R.id.iconoresultado)).setImageResource(R.mipmap.comprobado);
                            ((TextView) findViewById(R.id.Error)).setText("Correcto!!");
                            Log.e("estado","entro"+preguntas[i].tipo);

                            Siguiente.setVisibility(View.INVISIBLE);
                            ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.VISIBLE);



                        } else if (estadopregunta == 0) {
                            ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.VISIBLE);
                            ((ImageView) findViewById(R.id.iconoresultado)).setImageResource(R.mipmap.interrogacion);
                            ((TextView) findViewById(R.id.Error)).setText("Selecione");
                        } else if (estadopregunta == 2) {
                            ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.VISIBLE);
                            ((ImageView) findViewById(R.id.iconoresultado)).setImageResource(R.mipmap.errorrojo);
                            ((TextView) findViewById(R.id.Error)).setText("Incorrecta");
                            NumeroVidas--;
                            if(NumeroVidas== 1){
                                ((ImageView)findViewById(R.id.corazon1)).setImageResource(R.mipmap.corazonroto);
                            }
                            if(NumeroVidas==0){
                                if(!(user.getExp() <600)) {
                                    ((ImageView) findViewById(R.id.corazon2)).setImageResource(R.mipmap.corazonroto);
                                    AlertDialog.Builder Buider = new AlertDialog.Builder(Test.this);
                                    Buider.setMessage("Quiere seguir jugando?\n Compra un corazon por 600.....")
                                            .setCancelable(false)
                                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    NumeroVidas++;
                                                    ((ImageView) findViewById(R.id.corazon1)).setImageResource(R.mipmap.corazon);
                                                    user.setExp(user.getExp() - 600);
                                                    try {
                                                        user.UsuarioActivo(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                                    } catch (IOException error) {

                                                    }

                                                }
                                            })
                                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    finish();
                                                }
                                            });
                                    Buider.create().show();
                                }else {
                                    AlertDialog.Builder Buider = new AlertDialog.Builder(Test.this);
                                    Buider.setMessage("Has perdido, Nivel no superado")
                                            .setCancelable(false)
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                    finish();

                                                }
                                            });

                                    Buider.create().show();
                                }
                            }
                        }

                    }

            }
        });
        (findViewById(R.id.Saltar)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user.getNumeroDeSaltar() !=0){
                    AlertDialog.Builder Buider = new AlertDialog.Builder(Test.this);
                    Buider.setMessage("Quiere pasar el nivel?")
                            .setCancelable(false)
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    user.setNumeroDeSaltar(user.getNumeroDeSaltar()-1);
                                    progressBar.incrementProgressBy(1);
                                    if (i == NumeroDepreguntas - 1 ) {


                                            Intent intent = new Intent(getApplicationContext(),NivelSuperado.class);
                                            intent.putExtra("Nivel",NivelJugando);
                                            intent.putExtra("Tema",TemaJugando);
                                            intent.putExtra("NumeroPreguntas",NumeroDepreguntas);
                                            startActivity(intent);

                                            finish();

                                        return;
                                    }
                                    try {
                                        user.UsuarioActivo(new OutputStreamWriter(getApplicationContext().openFileOutput("UsuariosActivos.txt", MODE_PRIVATE)));
                                        preguntas[i].PreguntaActiva(new OutputStreamWriter(openFileOutput("preguntaActiva.txt",MODE_PRIVATE)));
                                    } catch (IOException error) {
                                        Log.e(error.getLocalizedMessage(), error.getMessage());
                                    }


                                    ((TextView)findViewById(R.id.Numerodepregunta)).setText("Pregunta N° " +i);
                                    if(preguntas[i].tipo.equals("c") ){
                                        ((TextView) findViewById(R.id.Error)).setText("");
                                        ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                                        Siguiente.setVisibility(View.VISIBLE);
                                        Siguiente.setImageResource(R.drawable.button_calificargris);
                                        ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                                        estadopregunta= 0;
                                        PreguntatipoC pregunta = new PreguntatipoC();
                                        pregunta.Recibir(preguntas[i]);

                                        Log.e("Test", "entro en click" + i);
                                        FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                                        i++;
                                    }else if(preguntas[i].tipo.equals("f")){
                                        ((TextView) findViewById(R.id.Error)).setText("");
                                        ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                                        Siguiente.setVisibility(View.VISIBLE);
                                        Siguiente.setImageResource(R.drawable.button_calificargris);
                                        ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                                        estadopregunta= 0;
                                        PreguntaF pregunta = new PreguntaF();
                                        pregunta.Recibir(preguntas[i]);

                                        Log.e("Test", "entro en click" + i);
                                        FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                                        i++;
                                    }else{
                                        ((TextView) findViewById(R.id.Error)).setText("");
                                        ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
                                        Siguiente.setVisibility(View.VISIBLE);
                                        Siguiente.setImageResource(R.drawable.button_calificargris);
                                        ((ImageView)findViewById(R.id.NextLevel)).setVisibility(View.INVISIBLE);
                                        estadopregunta= 0;
                                        Pregunta pregunta = new Pregunta();
                                        pregunta.Recibir(preguntas[i]);

                                        Log.e("Test", "entro en click" + i);
                                        FM.beginTransaction().replace(R.id.Fragmentcontainer, pregunta).commit();
                                        i++;
                                    }
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                    Buider.create().show();
                }else{
                    Toast.makeText(getApplicationContext(),"No tienes el bunus saltar",Toast.LENGTH_SHORT).show();
                }
            }
        });



        /*pager = (ViewPager) findViewById(R.id.pager);

        mPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        pager.setAdapter(mPagerAdapter);*/


    }
   @Override
    public void onBackPressed() {
       AlertDialog.Builder Buider = new AlertDialog.Builder(Test.this);
       Buider.setMessage("Quiere Salir del Nivel?")
               .setCancelable(false)
               .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {
                       Intent intent = new Intent(Test.this,Menu_opciones.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);;
                       startActivity(intent);
                       finish();
                   }
               })
               .setNegativeButton("No", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {

                   }
               });
       Buider.create().show();
    }
        @Override
        public void onFragmentInteraction(Integer i){
            ((TextView) findViewById(R.id.Error)).setText("");
            ((ImageView) findViewById(R.id.iconoresultado)).setVisibility(View.INVISIBLE);
            Siguiente.setImageResource(R.drawable.button_calificar);
            Log.e("Iteration","entro"+i);
            this.estadopregunta = i;

        }

}


