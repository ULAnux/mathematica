package ve.unix.ula.mathematicaapp;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * Created by mator on 04/12/16.
 */

public class Preguntas implements Parcelable {
    public Integer Tema,nivel, NumeroPregunta;
    public String tipo, preguntas;
    public String Opciones[], Respuesta;
    public Integer Exp;

    public Preguntas(String pregunta){
        System.out.println(pregunta);

        String Codigo = pregunta.substring(pregunta.indexOf("-")+1, pregunta.indexOf(","));
        pregunta = pregunta.substring(pregunta.indexOf(",")+1);
        System.out.println(Codigo);
        Tema = new Integer(new String(""+Codigo.charAt(0)));

        Codigo = Codigo.substring(Codigo.indexOf(".")+1);
        nivel = new Integer(new String(""+Codigo.charAt(0)));
        Codigo = Codigo.substring(Codigo.indexOf(".")+1);
        NumeroPregunta= new Integer(new String(""+Codigo.charAt(0)));
        Codigo = Codigo.substring(Codigo.indexOf("-")+1);
        tipo=Codigo;

        if(tipo.equals("a")){
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("A)"));
            pregunta = pregunta.substring(pregunta.indexOf("A)"));
            Opciones = new String[3];
            Opciones[0] = pregunta.substring(pregunta.indexOf("A)")+2,pregunta.indexOf("B)"));
            Opciones[1] = pregunta.substring(pregunta.indexOf("B)")+2,pregunta.indexOf("C)"));
            Opciones[2] = pregunta.substring(pregunta.indexOf("C)")+2,pregunta.indexOf("'"));
            pregunta = pregunta.substring(pregunta.indexOf("]")+1);
            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));
        }else if(tipo.equals("b")){
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("A)"));
            pregunta = pregunta.substring(pregunta.indexOf("A)"));
            Opciones = new String[2];
            Opciones[0] = pregunta.substring(pregunta.indexOf("A)")+2,pregunta.indexOf("B)"));
            Opciones[1] = pregunta.substring(pregunta.indexOf("B)")+2,pregunta.indexOf("'"));
            pregunta = pregunta.substring(pregunta.indexOf("]")+1);
            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));

        }else if(tipo.equals("c")){
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones = new String[11];
            Opciones[0] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[1] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[2] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[3] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[4] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[5] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[6] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[7] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[8] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[9] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[10] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(",")+1);

            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));
        }else if(tipo.equals("d")){
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("A)"));
            pregunta = pregunta.substring(pregunta.indexOf("A)"));
            Opciones = new String[4];
            Opciones[0] = pregunta.substring(pregunta.indexOf("A)")+2,pregunta.indexOf("B)"));
            Opciones[1] = pregunta.substring(pregunta.indexOf("B)")+2,pregunta.indexOf("C)"));
            Opciones[2] = pregunta.substring(pregunta.indexOf("C)")+2,pregunta.indexOf("D)"));
            Opciones[3] = pregunta.substring(pregunta.indexOf("D)")+2,pregunta.indexOf("'"));
            pregunta = pregunta.substring(pregunta.indexOf("]")+1);
            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));
        }else if(tipo.equals("e")){
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("A)"));
            pregunta = pregunta.substring(pregunta.indexOf("A)"));
            Opciones = new String[5];
            Opciones[0] = pregunta.substring(pregunta.indexOf("A)")+2,pregunta.indexOf("B)"));
            Opciones[1] = pregunta.substring(pregunta.indexOf("B)")+2,pregunta.indexOf("C)"));
            Opciones[2] = pregunta.substring(pregunta.indexOf("C)")+2,pregunta.indexOf("D)"));
            Opciones[3] = pregunta.substring(pregunta.indexOf("D)")+2,pregunta.indexOf("E)"));
            Opciones[4] = pregunta.substring(pregunta.indexOf("E)")+2,pregunta.indexOf("'"));
            pregunta = pregunta.substring(pregunta.indexOf("]")+1);
            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));
        }else if(tipo.equals("f")){
            System.out.println(tipo + "entro en el constructor");
            preguntas = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf(".")-1);
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones = new String[16];
            Opciones[0] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[1] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[2] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[3] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[4] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[5] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[6] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[7] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[8] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[9] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[10] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[11] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[12] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(".")+1);
            Opciones[13] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[14] = pregunta.substring(0,pregunta.indexOf("|"));
            pregunta = pregunta.substring(pregunta.indexOf("|")+1);
            Opciones[15] = pregunta.substring(0,pregunta.indexOf("."));
            pregunta = pregunta.substring(pregunta.indexOf(",")+1);

            Respuesta = pregunta.substring(pregunta.indexOf("'")+1,pregunta.indexOf("]")-1);
            Exp = new Integer(pregunta.substring(pregunta.indexOf("/")-2,pregunta.indexOf("/")));
        }else{
            System.out.println("Error" + this.tipo);
        }

    }


    protected Preguntas(Parcel in) {
        preguntas = in.readString();
        tipo = in.readString();
        Respuesta = in.readString();
        Tema = in.readInt();
        nivel = in.readInt();
        NumeroPregunta = in.readInt();
        Exp = in.readInt();
        in.readStringArray(Opciones);


    }
    private void readFromParcel(Parcel in) {
        preguntas = in.readString();
        tipo = in.readString();
        Respuesta = in.readString();
        Tema = in.readInt();
        nivel = in.readInt();
        NumeroPregunta = in.readInt();
        Exp = in.readInt();
        in.readStringArray(Opciones);
    }
    public static final Creator<Preguntas> CREATOR = new Creator<Preguntas>() {
        @Override
        public Preguntas createFromParcel(Parcel in) {
            return new Preguntas(in);
        }

        @Override
        public Preguntas[] newArray(int size) {
            return new Preguntas[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(preguntas);
        dest.writeString(tipo);
        dest.writeString(Respuesta);
        dest.writeInt(Tema);
        dest.writeInt(nivel);
        dest.writeInt(NumeroPregunta);
        dest.writeInt(Exp);
        dest.writeStringArray(Opciones);

    }
    public String toString(){

        return (preguntas+":"+tipo+":"+Respuesta+":"+Tema+":"+nivel+":"+NumeroPregunta+":"+Exp+":");
    }
    public void PreguntaActiva(OutputStreamWriter Archivo){
        try {
            Archivo.write(this.toString());
            Archivo.close();
        }catch (IOException error){
            Log.e(error.getLocalizedMessage(),error.getMessage());
        }
    }
    public Preguntas(){

    }
    public void LLenarPreguntaActiva(BufferedReader Archivo){

        String line;
        try {
            line= Archivo.readLine();

            this.preguntas = line.substring(0,line.indexOf(':'));
            line = line.substring(line.indexOf(':') + 1);
            this.tipo = line.substring(0,line.indexOf(':'));
            line = line.substring(line.indexOf(':') + 1);
            this.Respuesta = line.substring(0,line.indexOf(':'));
            line = line.substring(line.indexOf(':') + 1);
            this.Tema = new Integer(line.substring(0,line.indexOf(':')));
            line = line.substring(line.indexOf(':') + 1);
            this.nivel = new Integer(line.substring(0,line.indexOf(':')));
            line = line.substring(line.indexOf(':') + 1);
            this.NumeroPregunta = new Integer(line.substring(0,line.indexOf(':')));
            line = line.substring(line.indexOf(':') + 1);
            this.Exp = new Integer(line.substring(0,line.indexOf(':')));
           return;


        }catch (IOException r){

        }
    }
}
