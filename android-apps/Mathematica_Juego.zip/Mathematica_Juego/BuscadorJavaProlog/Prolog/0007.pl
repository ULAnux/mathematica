/*Teoria 1.1 Maria Fernanda Blanco CI022665358*/
pr(0007-1, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',aprender,a,construir,mensajes,claros,y,precisos],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-2, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',comunicarnos,efectivamente],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-3, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',saber,asignar,responsabilidades],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-4, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',comunicar,con,claridad],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-5, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',evitar,'ambigüedad'],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-6, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',entender,las,reglas],2/20, 'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-7, ['¿','Para',que,sirve,la,'lógica','?'],['Para',usar,los,'símbolos',correctamente],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-8, ['¿','Para','qué',sirve,la,'lógica','?'],['Para',distinguir,el,razonamiento,correcto,del,incorrecto],2/20,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-9, ['¿','Qué',es,una,'proposición','?'],['Es',una,oracion,a,la,que,se,le,puede,asignar,un,valor,de,verdad],1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u1.pdf').
pr(0007-10, [3,es,menor,que,5,'¿','Es',una,'proposición','?'],['Si'],1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u1.pdf').


pr(0007-11, ['�', 'Cu�les', fueron, las, motivaciones, de, 'arist�teles', para, inventar, la,'l�gica','?'],['El', deseo, por, conocer, la, verdad, acerca, de, la, naturaleza, de, los, argumentos], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-12, ['�', 'Cu�les', fueron, las, motivaciones, de, 'arist�teles', para, inventar, la,'l�gica','?'],['El', deseo, de, conocer, las, condiciones, bajo, las, cuales, algo, puede, considerarse, probado], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-13, ['�', 'Cu�les', fueron, las, motivaciones, de, 'arist�teles', para, inventar, la,'l�gica','?'],['El', deseo, de, refutar, el, argumento, de, un, oponente], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-14, ['�','Qu�', es, un, argumento,'?'],['Un', argumento, es, un, conjunto, de, proposiciones], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-15, ['�','Una', ' proposici�n',que, no, es, una, 'conclusi�n', es, una, '?'], ['Premisa'], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-16, ['�','�sta', ' proposici�n', es, cierta, o, falsa, '?', '"Un argumento v�lido es uno en el cual si las premisas son ciertas, entonces
necesariamente la conclusi�n debe ser cierta tambi�n."', 'cierto/falso'], [cierto], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-17, ['�','�sta', 'proposici�n', es, cierta, o, falsa, '?', 'Un argumento inv�lido es un argumento que es v�lido', 'cierto/falso'], ['falso'], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-18, ['�','�sta', 'proposici�n', es, cierta, o, falsa, '?',':', 'Un argumento inv�lido es un argumento que no es v�lido', 'cierto/falso'], ['cierto'], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-19, ['�','Cu�les', son, los,3, tipos, de, argumentos, 'seg�n' ,'Susan Haak[1978] ','?'], ['L�gicos', materiales,  y,  'ret�ricos'], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-20, ['"Una oraci�n con significado acerca
de la presencia de algo en un sujeto o de su ausencia"', 'Es', la, 'definici�n', de, 'proposici�n', 'seg�n', ':'], ['Arist�teles'], 1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-21, ['Considere este argumento: �El glaucoma no tratado es causa principal de una ceguera progresiva sin dolor. Se dispone de m�todos para la detecci�n oportuna y el tratamiento efectivo. Por esta raz�n, la ceguera por glaucoma es especialmente tr�gica� (Harvard Medical School Health letter, abril 1979, p 2)', '�Por', 'qu�', se, considera, especialmente, 'tr�gica', la, ceguera, por, glaucoma, '?'], ['No', ve, que, no, ve], 5/10,'http://jacinto-davila.blogspot.com/2014/10/bitacora-03-md-u2014-problemas-del.html').
pr(0007-22, ['En', cierta, comunidad, 'm�tica', los, 'pol�ticos', nunca, dicen, la, verdad, y, los, no, 'pol�ticos', siempre, dicen, la, verdad,'.', 'Un', 'extra�o', se, encuentra, con, tres, nativos, y, le, pregunta, al, primero, de, ellos,':', '�Eres un pol�tico?', '.',  'El', primer, nativo, responde, a, la, pregunta, '.', 'El', segundo, nativo, dice, entonces, que, el, primero, 'neg�', ser, un, 'pol�tico','.', 'El', tercer, nativo, dice, que, el, primer, nativo, es, un, 'pol�tico', '.', '�','Cu�ntos', de, los, nativos, son, 'pol�ticos','?'], [1], 5/10,'http://jacinto-davila.blogspot.com/2014/10/bitacora-03-md-u2014-problemas-del.html').
pr(0007-23, ['Una', 'ecuaci�n',	'que', 'describe', una, 'funci�n', en, 't�rminos', del, propio, valor, de, la, 'funci�n', para, argumentos, 'm�s', cercanos, a, 'alg�n', caso, 'b�sico', para, el, que, la, 'funci�n', 'est�', definida, 'expl�citamente', es, una,':'], ['Recurrencia'], 1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').

pr(0007-24, ['Una', 'ecuaci�n', de , recurrencia, de, la, forma, 'anT(n) + an-1T(n - 1) + . . . + an-kT(n - k) = 0', es, ':'], [lineal, 'homog�nea'], 1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').

pr(0007-25, ['Una', 'ecuaci�n', de , recurrencia, de, la, forma, 'anT(n) + an-1T(n - 1) + . . . + an-kT(n - k) = b^n p(n)', es, ':'], [lineal ,no ,'homog�nea'], 1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').

pr(0007-26, ['Es', un, lenguaje, de, 'c�lculo', 'simb�lico', escrito, en, 'Lisp', ':'], ['Maxima'], 1/1,'http://nux.ula.ve/mathematica/maxima.pdf').

pr(0007-27,['Es', un, conjunto, cerrado, respecto, de, una, 'operaci�n', asociativa, con, cero, e, inverso, ':'], ['Grupo'], 1/2,'http://nux.ula.ve/mathematica/resumen-estructuras-algebraicas.pdf').

pr(0007-28,['Un', grupo, es, conmutativo, o, abeliano, si, 'adem�s', de, cumplir, las, reglas, indicadas, ',', la, operacion, '(+)', es, ':'], ['Conmutativa'], 1/2,'http://nux.ula.ve/mathematica/resumen-estructuras-algebraicas.pdf').


pr(0007-29,['�', 'Qu�', es, 'programaci�n', 'l�gica', '?'], ['Es', un, paradigma, de, 'computaci�n', que, consiste, de, un, enfoque, declarativo, para, escribir, programas, para, el, computador,'.'], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-29,['�', 'Cu�l', es, el, lenguaje, que, tiene, un, significado, operacional, preciso, que, toma, prestados, sus, conceptos, 'b�sicos', de, la, 'programaci�n', 'l�gica', '?'], ['PROLOG'], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-30,['�', 'Qu�', es, un, programa, en, 'PROLOG','?'], ['Es', un, conjunto, de, procedimientos, que, consiste, de, una, o, 'm�s', clausulas], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-31,['�', 'Cu�les', son, los, tipos, de, clausulas, '?'], ['Hechos', y, reglas], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-32,['Los', programas, prolog, se, almacenan, en, una, ':'], ['Base', de, conocimiento], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-33,['Con', 'qu�', comando, se, carga, un, programa, dentro, de, la, base, de, datos, desde, la, concha, de, 'PROLOG'],['Consult';consult], 1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').

pr(0007-34,['Para', poder, analizar, el, 'desempe�o', de, un, algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste', requiere, '.', '�', 'Cu�les', son, estos, recursos, '?'],['Cantidad', de, almacenamiento, requerido, por, sus, variables], (1/5)/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-35,['Para', poder, analizar, el, 'desempe�o', de, un, algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste', requiere, '.', '�', 'Cu�les', son, estos, recursos, '?'],['Cantidad', de, 'informaci�n', que, debe, moverse], (1/5)/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-36,['Para', poder, analizar, el, 'desempe�o', de, un, algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste', requiere, '.', '�', 'Cu�les', son, estos, recursos, '?'],['Cantidad', de, 'tr�fico', que, genera, en, una, red], (1/5)/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-37,['Para', poder, analizar, el, 'desempe�o', de, un, algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste', requiere, '.', '�', 'Cu�les', son, estos, recursos, '?'],['Simplicidad', del, algoritmo], (1/5)/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-38,['Para', poder, analizar, el, 'desempe�o', de, un, algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste', requiere, '.', '�', 'Cu�les', son, estos, recursos, '?'],['Tiempo', de, computo], (1/5)/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-39,['�','Cu�l', es, el, criterio, para, medir, el, uso, del, tiempo, de, 'c�lculo', en, un, computador, '?'],['Complejidad', temporal], 1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-40,['�','Cu�l', es, el, criterio, para, medir, el, uso, del, espacio, en, un, computador, '?'],['Complejidad', espacial], 1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-41,['Sea', n, el, 'tama�o',de, la, entrada, de, un,algoritmo,',','La', 'funci�n', que, relaciona, el, tiempo, de, corrida, con, el, 'tama�o', 'T(n)', representa, su, ':'],['Complejidad', computacional], 1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-42,['Cuando', la, complejidad, del, algoritmo, es, una, 'funcion', constante,'"no depende de n"', ',' , hablamos, de, una, complejidad, ':'],['constante'], 1/6,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-43,['Cuando', la, complejidad, del, algoritmo, es, una, 'funcion',del, tipo, ' T(n)=an+b', hablamos, de, una, complejidad, ':'],['lineal'], 1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-44,['Cuando', la, complejidad, del, algoritmo, es, una, 'funcion',del, tipo, 'T(n)=an^2+bn+c', hablamos, de, una, complejidad, ':'],['cuadr�tica'], 1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').



/*
Sujerencia para el formato
000X-01-Y = Pr numero Y de el sujeto X del tema de LOGICA
000X-02-Y = Pr numero Y de el sujeto X del tema de CONJUNTOS Y FUNCIONES
000X-03-Y = Pr numero Y de el sujeto X del tema de ESTRUCTURAS
ALGEBRAICAS
000X-04-Y = Pr numero Y de el sujeto X del tema de INDUCCI�N MATEM�TICA
000X-05-Y = Pr numero Y de el sujeto X del tema de COMBINATORIA
000X-06-Y = Pr numero Y de el sujeto X del tema de FUNCIONES
GENERATRICES
000X-07-Y = Pr numero Y de el sujeto X del tema de
RECURRENCIAS
000X-08-Y = Pr numero Y de el sujeto X del tema de INTRODUCION A LA
COMPLEJIDAD COMPUTACIONAL
000X-09-Y = Pr numero Y de elsujeto X del tema
de MAXIMA
000X-10-Y = Pr numero Y de el sujeto X del tema de PROLOG

mis prs con este formato

pr(0007-01-1,
['¿','Para','qué',sirve,la,'lógica','?'],['Para',aprender,a,construir,mensajes,claros,y,precisos],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-2,['¿','Para','qué',sirve,la,'lógica','?'],['Para',comunicarnos,efectivamente],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-3,['¿','Para','qué',sirve,la,'lógica','?'],['Para',saber,asignar,responsabilidades],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-4,['¿','Para','qué',sirve,la,'lógica','?'],['Para',comunicar,con,claridad],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-5,['¿','Para','qué',sirve,la,'lógica','?'],['Para',evitar,'ambigüedad'],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-6,['¿','Para','qué',sirve,la,'lógica','?'],['Para',entender,las,reglas],2/20,
'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-7,['¿','Para',que,sirve,la,'lógica','?'],['Para',usar,los,'símbolos',correctamente],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-8,['¿','Para','qué',sirve,la,'lógica','?'],['Para',distinguir,el,razonamiento,correcto,del,incorrecto],2/20,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-9,['¿','Qué',es,una,'proposición','?'],['Es',una,oracion,a,la,que,se,le,puede,asignar,un,valor,de,verdad],1/10,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u1.pdf').
pr(0007-01-10,[3,es,menor,que,5,'¿','Es',una,'proposición','?'],['Si'],1/10,'Jacinto
D�vila, http://nux.ula.ve/mathematica/lm-u1.pdf').


pr(0007-01-11, ['�', 'Cu�les', fueron, las, motivaciones, de,
'arist�teles', para, inventar, la,'l�gica','?'],['El', deseo, por,
conocer, la, verdad, acerca, de, la, naturaleza, de, los, argumentos],
1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-12, ['�', 'Cu�les', fueron, las, motivaciones, de,
'arist�teles', para, inventar, la,'l�gica','?'],['El', deseo, de,
conocer, las, condiciones, bajo, las, cuales, algo, puede, considerarse,
probado], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-13, ['�','Cu�les', fueron, las, motivaciones, de, 'arist�teles', para, inventar,
la,'l�gica','?'],['El', deseo, de, refutar, el, argumento, de, un,
oponente], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-14, ['�','Qu�', es, un, argumento,'?'],['Un', argumento, es,
un, conjunto, de, proposiciones], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf'). pr(0007-1-15, ['�','Una', '
proposici�n',que, no, es, una, 'conclusi�n', es, una, '?'], ['Premisa'],
1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-16, ['�','�sta', proposici�n, es, cierta, o, falsa, '?', '"Un
argumento v�lido es uno en el cual si las premisas son ciertas, entonces
necesariamente la conclusi�n debe ser cierta tambi�n."',
'cierto/falso'], [cierto], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-17, ['�','�sta', proposici�n, es, cierta, o, falsa, '?', 'Un
argumento inv�lido es un argumento que es v�lido', 'cierto/falso'],
['falso'], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-18, ['�','�sta', proposici�n, es, cierta, o, falsa, '?',':',
'Un argumento inv�lido es un argumento que no es v�lido',
'cierto/falso'], ['cierto'], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-19, ['�','Cu�les',son, los,3, tipos, de, argumentos, 'seg�n'
,'Susan Haak[1978] ','?'], ['L�gicos', materiales, y, 'ret�ricos'],
1/10,'Jacinto D�vila, http://nux.ula.ve/mathematica/lm-u0.pdf').
pr(0007-01-20, ['"Una oraci�n con significado acerca de la presencia de
algo en un sujeto o de su ausencia"', 'Es', la, 'definici�n', de,
'proposici�n', 'seg�n', ':'], ['Arist�teles'], 1/10,'Jacinto D�vila,
http://nux.ula.ve/mathematica/lm-u0.pdf').

pr(0007-01-21, ['Considere este argumento: �El glaucoma no tratado es
causa principal de una ceguera progresiva sin dolor. Se dispone de
m�todos para la detecci�n oportuna y el tratamiento efectivo. Por esta
raz�n, la ceguera por glaucoma es especialmente tr�gica� (Harvard
Medical School Health letter, abril 1979, p 2)', '�Por', 'qu�', se,
considera, especialmente, tr�gica, la, ceguera, por, glaucoma, '?'],
['No', ve, que, no, ve],
5/10,'http://jacinto-davila.blogspot.com/2014/10/bitacora-03-md-u2014-problemas-del.html').


pr(0007-01-22, ['En', cierta, comunidad, 'm�tica', los, pol�ticos,
nunca, dicen, la, verdad, y, los, no, pol�ticos, siempre, dicen, la,
verdad,'.', 'Un', extra�o, se, encuentra, con, tres, nativos, y, le,
pregunta, al, primero, de, ellos,':', '��Eres un pol�tico?�', '.', 'El',
primer, nativo, responde, a, la, pregunta, '.', 'El', segundo, nativo,
dice, entonces, que, el, primero, neg�, ser, un, pol�tico,'.', 'El',
tercer, nativo, dice, que, el, primer, nativo, es, un, pol�tico, '.',
'�','Cu�ntos', de, los, nativos, son, 'pol�ticos','?'], [1],
5/10,'http://jacinto-davila.blogspot.com/2014/10/bitacora-03-md-u2014-problemas-del.html').


pr(0007-07-23, ['Una', 'ecuaci�n', 'que', 'describe', una, 'funci�n',
					en, 't�rminos', del, propio,
					valor, de, la, 'funci�n', para,
					argumentos, 'm�s', cercanos, a,
					'alg�n', caso, 'b�sico', para,
					el, que, la, 'funci�n', 'est�',
					definida, 'expl�citamente', es,
					una,':'], ['Recurrencia'],
					1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').


pr(0007-07-24, ['Una', 'ecuaci�n', de , recurrencia, de, la, forma,
'anT(n) + an-1T(n - 1) + . . . + an-kT(n - k) = 0', es, ':'], [lineal,
'homog�nea'], 1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').

pr(0007-07-25, ['Una', 'ecuaci�n', de , recurrencia, de, la, forma,
'anT(n) + an-1T(n - 1) + . . . + an-kT(n - k) = b^n p(n)', es, ':'],
[lineal ,no ,'homog�nea'],
1/3,'http://nux.ula.ve/mathematica/Bermudez.pdf').

pr(0007-09-26, ['Es', un, lenguaje, de, 'c�lculo', 'simb�lico', escrito,
en, 'Lisp', ':'], ['Maxima'],
1/1,'http://nux.ula.ve/mathematica/maxima.pdf').

pr(0007-03-27,['Es', un, conjunto, cerrado, respecto, de, una,
'operaci�n', asociativa, con, cero, e, inverso, ':'], ['Grupo'],
1/2,'http://nux.ula.ve/mathematica/resumen-estructuras-algebraicas.pdf').


pr(0007-03-28,['Un', grupo, es, conmutativo, o, abeliano, si, 'adem�s',
de, cumplir, las, reglas, indicadas, ',', la, operacion, '(+)', es,
':'], ['Conmutativa'],
1/2,'http://nux.ula.ve/mathematica/resumen-estructuras-algebraicas.pdf').



pr(0007-10-29,['�', 'Qu�', es, 'programaci�n', 'l�gica', '?'], ['Es',
un, paradigma, de, 'computaci�n', que, consiste, de, un, enfoque,
declarativo, para, escribir, programas, para, el, computador,'.'],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').



pr(0007-10-29,['�', 'Cu�l', es, el, lenguaje, que, tiene, un,
significado, operacional, preciso, que, toma, prestados, sus, conceptos,
'b�sicos', de, la, 'programaci�n', 'l�gica', '?'], ['PROLOG'],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').



pr(0007-10-30,['�', 'Qu�', es, un, programa, en, 'PROLOG','?'], ['Es',
un, conjunto, de, procedimientos, que, consiste, de, una, o, 'm�s',
clausulas],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').



pr(0007-10-31,['�', 'Cu�les', son, los, tipos, de, clausulas, '?'],
['Hechos', y, reglas],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').


pr(0007-10-32,['Los', programas, prolog, se, almacenan, en, una, ':'],
['Base', de, conocimiento],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').


pr(0007-10-32,['Con', 'qu�', comando, se, carga, un, programa, dentro,
de, la, base, de, datos, desde, la, concha, de,
'PROLOG'],['Consult';consult],
1/6,'http://webdelprofesor.ula.ve/ingenieria/jacinto/logica/manual-prolog/introduccion-prolog.html').



pr(0007-08-33,['Para', poder, analizar, el, desempe�o, de, un,
algoritmo, ',', debemos, predecir, los, recursos, 'qu�', '�ste',
requiere, '.', '�', 'Cuales', son, estos, recursos, '?'],['Cantidad',
de, almacenamiento, requerido, por, sus, varibles;'Cantidad', de,
'informaci�n', que, debe, moverse; 'Cantidad', de, trafico, que, genera,
en, una, red;'Simplicidad', del, algoritmo; 'Tiempo', de, computo],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-34,['�','Cu�l', es, el, criterio, para, medir, el, uso, del,
tiempo, de, 'c�lculo', en, un, computador, '?'],['Complejidad',
temporal],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-35,['�','Cu�l', es, el, criterio, para, medir, el, uso, del,
espacio, en, un, computador, '?'],['Complejidad', espacial],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-35,['Sea', n, el, 'tama�o',de, la, entrada, de,
un,algoritmo,',','La', 'funci�n', que, relaciona, el, tiempo, de,
corrida, con, el, 'tama�o', 'T(n)', representa, su, ':'],['Complejidad',
computacional],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-36,['Cuando', la, complejidad, del, algoritmo, es, una,
'funcion', constante,'"no depende de n"', ',' , hablamos, de, una,
complejidad, ':'],['constante'],
1/6,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-37,['Cuando', la, complejidad, del, algoritmo, es, una,
'funcion',del, tipo, ' T(n)=an+b', hablamos, de, una, complejidad,
':'],['lineal'],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

pr(0007-08-38,['Cuando', la, complejidad, del, algoritmo, es, una,
'funcion',del, tipo, 'T(n)=an^2+bn+c', hablamos, de, una, complejidad,
':'],['cuadr�tica'],
1/7,'http://nux.ula.ve/mathematica/complejidad-computacional.pdf').

*/









