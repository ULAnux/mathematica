pr(0009-1, ['Que es un argumento'], ['Se refiere a toda secuencia de pala0000-1bras conectadas entre si, que establece una conclusiÃƒÂ³n'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/Argumento']).
pr(0009-2, ['Validez de un argumento'], ['Un argumento es valido si siempre que sus condiciones son ciertas, sus conclusiones son ciertas'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Validez_%28l%C3%B3gica%29']).
pr(0009-3, ['Notacion y'], ['La palabra lÃƒÂ³gica y se puede denotar como ^,&&,&,and y /\\ '], 20/20, ['Urbaez']).
pr(0009-4, ['(A+B)^2 ='], ['A^2 + 2*A*B + B^2'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Productos_notables']).
pr(0009-5, ['(A-B)^2 ='], ['A^2 - 2*A*B + B^2'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Productos_notables']).
pr(0009-6, ['(A+B)*(A-B) ='], ['A^2 - B^2'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Productos_notables']).
pr(0009-7, ['(A+B)^3 ='], ['A^3 + 3*A^2*B + 3*A*B^2 + B^3'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Productos_notables']).
pr(0009-8, ['(A-B)^3 ='], ['A^3 - 3*A^2*B + 3*A*B^2 - B^3'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Productos_notables']).
pr(0009-9, ['Que es un conjunto'], ['Una agrupaciÃƒÂ³n de elementos considerada como un objeto.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conjunto']).
pr(0009-10, ['Notacion de un conjunto'], ['Un conjunto se denota con {}.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-11, ['{A,B} ='], ['{B,A}'], 20/20, ['Urbaez basado en: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-12, ['Conjunto de los planetas del sistema solar'], ['El conjunto de los planetas del sistema solar se define como P = {Mercurio,Venus,Tierra,Marte,JÃƒÂºpiter,Saturno,Urano,Neptuno}.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-13, ['Que es un numero'], ['Es la expresiÃƒÂ³n de una cantidad en relaciÃƒÂ³n a su unidad.'], 20/20, ['Urbaez basado en: http://www.wordreference.com/definicion/numero']).
pr(0009-14, ['Que es un numero'], ['Un valor.'], 5/20, ['Urbaez basado en: http://www.wordreference.com/definicion/numero']).
pr(0009-15, ['Notacion de los numeros reales'], ['El conjunto de los numeros reales se denotan con la letra R.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_real']).
pr(0009-16, ['Notacion de los numeros naturales'], ['El conjunto de los numeros naturales se denotan con la letra N.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_natural']).
pr(0009-17, ['Notacion de los numeros racionales'], ['El conjunto de los numeros racionales se denotan con la letra Q.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_racional']).
pr(0009-18, ['Notacion de los numeros enteros'], ['El conjunto de los numeros enteros se denotan con la letra Z.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_entero']).
pr(0009-19, ['Cuando un elemento pertenece a un conjunto?'], ['Cuando ese elemento esta contenido en ese conjunto'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-20, ['Cuando un elemento pertenece a un conjunto?'], ['Cuando ese elemento esta contenido en ese conjunto'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-21, ['Conjunto numeros enteros entre -6 y  +50'], ['P = {x | -6 <= x <= 50}'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-22, ['B C A'], ['B esta contenido en el conjunto A.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-23, ['Notacion de pertenencia'], ['Cuando un elemento X pertenece a un conjunto A se denota como X Ã¢Ë†Ë† A'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-24, ['Que es union'], ['La uniÃƒÂ³n de dos conjuntos A y B es un conjunto C que tiene los elementos de A y de B.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-25, ['Notacion variacion'], ['La variacion es denotada como Vm,n.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-26, ['Notacion combinatoria'], ['La combinatoria es denotada como Cm,n.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-27, ['Notacion permutacion'], ['La permutacion se denota como Pm'],20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-28, ['Numero factorial'], ['Un numero factorial m es el producto de todos los numeros decrecientes desde m hasta 1.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-29, ['Ã‚Â¿Cuantas sumas diferentes de dos sumandos cada una se puede realizar con los numeros 3,6,12,21,13,41'], ['Tenemos 2 sumandos por ejemplo A y B entonces A+B = B+A por lo tanto el orden no importa, entonces es una combinatoria, C6,2 = (6!)/(4!*2!) y esto nos queda 15.'], 20/20,['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-30, ['Ã‚Â¿De cuantas maneras diferentes pueden colocarse 4 soldados en una fila?'], ['Como el orden de los soldados importa tenemos que es una variacion, V4,4 = 4 * 3 * 2 * 1 = 4! = 24.'],20 /20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-31, ['Ã‚Â¿Cuantos sabores pueden formarse con 5 marcas de vino?'], ['Ya que al mezclar en cualquier orden se va a llegar al mismo sabor, vemos que no importa el orden por ende es una combinatoria, C5,5 = 1.'], 20/20,['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-32, ['Se dispone de 13 monedas diferentes Ã‚Â¿Cuantas colecciones
pueden hacerse entrando en cada coleccion 6 monedas?'], ['Ya que la
coleccion A,B,C,D,E,F por ejemplo es igual en el orden que se coloque
entonces por ende inducimos que es una combinatoria, C13,6 = 13!/(7!*6!) =
1716.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-33, ['¿Cuantas seÃƒÂ±ales diferentes pueden hacerse con 11 banderas
izandolas de 4 en 4?'], ['Ya que al cambiar el orden de las banderas se
cambia la seÃƒÂ±al tenemos que es una variacion V11,4 = 11 * 10 * 9 * 8 =
7920.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-34, ['En una carrera de caballos figuran 10 ejemplares Ã‚Â¿De cuantas
maneras pueden llegar a la meta admitiendo que llegan de uno en uno?'],
['Ya que el orden si importa y se van a tomar todos los caballos en cuenta
entonces es una permutacion, por ende P10 = 10! = 3628800.'], 20/20,
['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-35, ['Ã‚Â¿Cuantos sonidos diferentes pueden emitirse pulsando
simultaneamente cuatro teclas en un piano?'], ['Ya que se pulsan todas al
mismo tiempo se produce un unico sonido, por lo tanto el resultado es 1.'],
20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-36, ['Se dispone de 10 soldados Ã‚Â¿Cuantas filas de a 5 soldados
pueden hacerse?'], ['Ya que el orden influye y solo se estan tomando filas
de a 5 entonces es una variacion, por lo tanto V10,5 = 10 * 9 * 8 * 7 * 6 =
30240.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-37, ['Ã‚Â¿Cuantas banderas de franjas horizontales de 4 colores se
pueden formar con los 7 colores del arcoiris sin repetir ningun color?'],
['Ya que el orden de los colores si importa ya que diferentes colores
forman diferentes banderas, tenemos que es una variacion. Entonces V7,4 = 7
* 6 * 5 * 4 = 840.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-38, ['Una habitacion tiene 5 puertas Ã‚Â¿De cuantas maneras se puede
entrar y salir por puertas diferentes?'], ['Dado que se usan 2 puertas una
para entrar y otra para salir y si importa el orden, tenemos que es una
Variacion, V5,2 = 5 * 4 = 20.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-39, ['Con las cifras del numero 5673214. Calcular cuantos nÃƒÂºmeros de
4 cifras pueden formarsen que empiezen por un 7'], ['Sabemos que tiene que
empezar por 7 entonces me quedan 6 numeros a repartir en 3 casillas, ya que
el orden hace numeros distintos entonces es una variacion, V6.3 = 6*5*4 =
120.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro']).
pr(0009-40, ['Con las cifras del numero 238647. Calcular cuantos numeros de 4 cifras pueden hacerse con la condicion de que empiezen en 2 y terminen en 8.'], ['Ya que empiezan en 2 y terminan en 8, nos quedan 4 numeros a repartir en 2 casillas, V4,2 = 4 * 3 = 12.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-41, ['Con las cifras del numero 374526. Calcular en cuantos numeros
de 3 cifras interviene el 7.'], ['El 7 puede aparecer como 7XX, X7X, XX7 entonces tenemos 3 formas y disponemos de 5 numeros para distribuir en 2 casillas, V5,2 = 5 * 4 = 20 como disponemos de 3 formas multiplicamos el resultado anterior por 3 y nos queda 3*20 = 60.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-42, ['Con las cifras del numero 360746. Calcular cuantos numeros de 5 cifras pueden hacerse'], ['Ya que el 0 a la izquierda no valdria como un numero de 5 cifras tenemos que 5*V5,4 = 5 * 5 * 4 * 3 * 2 = 600. '], 20/20,
['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-43, ['Con las cifras 1234578. Calcular cuantos numeros de 5 cifras terminan en 8'], ['La condicion es que sea XXXX8, entonces disponemos de 6 numeros para 4 casillas y el orden importa entonces es una variacion, V6,4 = 6 * 5 * 4 * 3 = 360.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
%Recurrencia
pr(0009-44, ['¿Que es una relacion de recurrencia?'], ['Una relacion de recurrencia es una ecuacion que define de una secuencia revursiva, cada termino de la secuencia es definido como una funcion de los terminos anteriores.'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/Relaci%C3%B3n_de_recurrencia']).
pr(0009-45, ['¿Que es una sucesion?'], ['Es una solucion de una relacion de recurrencia si sus terminos satisfacen la relacion para todo entero positivo n.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-46, ['¿Que es un algoritmo?'], ['Es un conjunto de instrucciones o reglas bien definidas, ordenadas y finitas que permite realizar una actividad mediante pasos sucesivos que no generen dudas a quien deba realizar dicha actividad.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Algoritmo']).
pr(0009-47, ['¿Que es recurrencia?'], ['Es una propiedad de las secuencias en las que cualquier termino se puede calcular conociendo los terminos precedentes.'], 20/20, ['Urbaez basado en: http://www.wordreference.com/definicion/recurrencia']).
pr(0009-48, ['¿Que es una relacion?'], ['Es la correspondencia de un elemento con otro.'], 20/20, ['Urbaez tomado de: http://www.wordreference.com/definicion/relacion']).
pr(0009-49, ['Â¿Serie de Fibonacci?'], ['La sucesiÃ³n empieza con 1 y 1 y a partir de estos cada termino es la suma de los 2 anteriores.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Sucesi%C3%B3n_de_Fibonacci']).
pr(0009-50, ['¿Quien es Fibonacci?'], ['Leonado de Pisa es su nombre y fue un matematico italiano, famoso por haber difundido en Eurioa el sistema de numeracion indo-arabigo, el cual emplea la notacion posicional y por idear la sucesion o serie de Fibonacci.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Leonardo_de_Pisa']).
pr(0009-51, ['Torres de Hanoi'], ['Un juego popular del siglo XIX. Una leyenda dice que este juego con 64 discos calcula el tiempo que le queda al mundo.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-52, ['Definicion del Numero de Catalan'], ['El numero de Catalan esta definido como C(2n,n) - C(2n,n-1) para todo n mayor o igual que 1.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-53, ['Aplicaciones del Numero de Catalan'], ['Con el numero de Catalan se puede obtener el numero de formas de cortar un poligono de n+2 lados en triangulos conectando vertices con lineas rectas sin que ninguna se corte, el numero de arboles binarios de n+1 hojas en los que cada nodo tiene cero o dos hijos.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-54, ['Aplicaciones de la serie de Fibonacci'], ['Sirve para calcular la reproduccion de conejos en determinados periodos de tiempo sujeto a ciertas condiciones.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-55, ['Aplicaciones de la serie de Fibonacci'], ['Sirve para contar el numero de distintas rutas que puede seguir una abeja que va recorriendo las celdillas hexagonales de un panal.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen']).
pr(0009-56, ['Numeros Triangulares'], ['Un numero triangular es aquel que puede recomponerse en la forma de un triangulo equilatero.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_triangular']).
pr(0009-57, ['Definicion numeros triangulares'], ['Los numeros triangulares se definen por la formula Tn = ((n)*(n+1))/2.'], 20/20, ['Urbaez basado en http://es.wikipedia.org/wiki/N%C3%BAmero_triangular']).
pr(0009-58, ['Numeros cuadrados'], ['Un numero es cuadrado perfecto si se puede ordenar en una figura cuadrada.'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/Cuadrado_perfecto']).
pr(0009-59, ['Numeros cuadrados'], ['Un numero es cuadrado si su raiz cuadrada es entera.'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/Cuadrado_perfecto']).
pr(0009-60, ['Triangulo de Pascal'], ['Es una representacion de los coeficientes binomiales ordenados en forma triangular.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Tri%C3%A1ngulo_de_Pascal']).
pr(0009-61, ['Numero tetraedrico'], ['Es un numero piramidal triangular, es un numero figurado que representa una piramide de base triangular y de 3 lados.'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/N%C3%BAmero_tetra%C3%A9drico']).
pr(0009-62, ['Definicion numeros tetraedricos'], ['Los numeros tetraedricos se definen de la siguiente forma: Tn = (1/6)*(n)*(n+1)*(n+2).'], 20/20, ['Urbaez tomado de: http://es.wikipedia.org/wiki/N%C3%BAmero_tetra%C3%A9drico']).
%Combinatoria
pr(0009-63, ['Con las cifras 8073214. Calcular cuantos numeros de 4 cifras se pueden formar'], ['Disponemos de 7 digitos, entonces en la primer digito pueden ir cualquiera de los 7 numeros menos el 0 porque son numeros de 4 cifras,despues disponemos de 3 casillas y de 6 numeros ya que importa el orden porque los numeros son diferentes con cifras diferentes entonces seria V6,3 = 6*5*4 = 120 numeros de 3 cifras y en la primera casilla se pueden poner 6 numeros, la cantidad de numeros de 4 cifras es 120 * 6 = 720.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-64, ['Con las cifras 9785431. Calcular cuantos numeros de 5 digitos que empiecen en 13 y intervenga el 7 se pueden formar'], ['Disponemos de 7 cifras, los 2 primeros digitos estan reservados para el 1 y el 3, ya que son numeros de 5 digitos nos sobran 3 casillas para colocar los otros. Entonces los numeros tienen esta forma 137XX o 13X7X o 13XX7 como vemos el 7 puede ir en 3 lugares, y nos sobran 4 numeros, ya que importa el orden debido a que son numeros entonces V4,2 = 12, multiplicando el numero anterior por las formas en que se puede colocar el 7 nos da 12* 3 = 36 numeros, que corresponde a los numeros que comiencen en 13 y que interviene el 7.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-65, ['Con las cifras 1234578. Calcular cuantos numeros de 5 cifras
terminan en 8.'], ['Los numeros son de la forma XXXX8 el 8 esta fijo en el ultimo digito, entonces debido a que si importa el orden tenemos un total de 7-1 digitos que podemos asignar es decir 6 digitos y disponemos de 4 casillas para estos. Por lo tanto V6,4 = 6*5*4*3 = 360 numeros se pueden formar con esa cifra y que terminen en 8.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-66, ['Con las cifras 127345. Calcular cuantos numeros de menores de 4000 pueden hacerse.'], ['Para que sea menor de 4000 la primera cifra puede ser 1,2 o 3 en las demas casillas pueden ir cualquiera con tal de que empiecen con estos 3 numeros antes mencionados, entonces disponemos de 3 casillas para un total de 5 numeros ya que seleccionamos uno de entre el 1,2 y el 3. La cantidad de numeros de 4 cifras son 3*V5,3 = 3*5*4*3 = 180, tambien debemos considerar los de 3 cifras, los de 2 y los de una cifra. Para los de una cifra son 6 numeros o V6,1 = 6, para los de 2 de igual forma pero V6,2 = 6*5 = 30 y para los de 3 seria V6,3 = 6*5*4 = 120. El total de numeros menores de 4 cifras es 180+120+6+30 = 336 numeros.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-67, ['Con las cifras 5374821. Calcular cuantos numeros mayores de 4000 pueden formarse que empiecen en 13 y intervenga el 7 se pueden formar'], ['Para que sea mayor de 4000 consideramos que tener mas de 5 digitos y si tiene 4 debe empezar en 4 o un numero mayor a este, entonces del numero 5374821 los numeros mayores o iguales a 4 son 5,7,8 y 4. Para los numeros de 4 digitos la primera casilla puede tener el 5,7,8 o el 4 es decir 4 numeros las demas pueden tener cualquier numero. La cantidad de numeros de 4 digitos seria 4 * V6,3 que corresponde a los 6 numeros que tome repartidos en 3 puestos donde importa el orden. Por lo tanto 4*(6*5*4) = 480 numeros de 4 cifras. Para los de 5,6 y 7 cifras respectivamente es mas sencillo ya que se pueden considerar todos los numeros que disponemos. Para los de 5 cifras seria V7,5, para los de 6 V7,6 y para los de 7 seria P7 ya que tomamos todos los numeros. La cantidad de numeros mayores que 4 mil son: 480 + V7,5 + V7,6 + P7 = 480 + (7*6*5*4*3) + (7*6*5*4*3*2) + 7! = 13080 numeros.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
pr(0009-68, ['Se dispone de 11 personas para formar grupos de 4 personas, Â¿Cuantos grupos pueden formarse?'], ['Ya que no mencionan algun orden de colocacion entonces un grupo ABCD = BCAD es decir va a ser igual en cualquiera de sus permutaciones ya que no importa el orden. En base a esto son combinaciones de 11 tomados de 4 en 4 lo que es igual a C11,4 = (11!)/(7!*4!) = 330 grupos diferentes de 4 personas se pueden formar.'], 20/20, ['Urbaez tomado de: Libro de matematicas de Navarro.']).
%Complejidad %Computacional
pr(0009-69, ['Funcion T(n)'], ['Representacion de la complejidad computacional.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/complejidad-computacional.pdf']).
pr(0009-70, ['O(1)'], ['Es una funcion constante.'], 20/20, ['Urbaez basado en http://nux.ula.ve/mathematica/complejidad-computacional.pdf']).
pr(0009-71, ['O(n)'], ['Es una funcion lineal.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/complejidad-computacional.pdf']).
pr(0009-72, ['O(log n)'], ['Funcion logaritmica.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/complejidad-computacional.pdf']).
pr(0009-73, ['Complejidad computacional'], ['Estudia la eficiencia de los algoritmos estableciendo su efectividad de acuerdo al tiempo de corrida y al espacio requerido en la computadora o almacenamiento de datos.'], 20/20, ['Urbaez basado en: http://www.ptolomeo.unam.mx:8080/xmlui/bitstream/handle/132.248.52.100/539/A5.pdf?sequence=5']).
pr(0009-74, ['Tiempo de ejecucion de la busqueda binaria'], ['O(log n)'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-75, ['Tiempo de ejecucion'], ['Es el tiempo que tarda el sistema operativo en ejecutar un programa.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Tiempo_de_ejecuci%C3%B3n']).
%Funciones
pr(0009-76, ['(f+g)(x) ='], ['f(x) + g(x)'], 20/20, ['Urbaez basado en: http://facultad.bayamon.inter.edu/ntoro/algfw.htm']).
pr(0009-77, ['(f-g)(x) ='], ['f(x) - g(x)'], 20/20, ['Urbaez basado en: http://facultad.bayamon.inter.edu/ntoro/algfw.htm']).
pr(0009-78, ['(f*g)(x) ='], ['f(x) * g(x)'], 20/20, ['Urbaez basado en: http://facultad.bayamon.inter.edu/ntoro/algfw.htm']).
pr(0009-79, ['(f/g)(x) ='], ['f(x)/g(x) con g(x) distinto de 0'], 20/20, ['Urbaez basado en: http://facultad.bayamon.inter.edu/ntoro/algfw.htm']).
pr(0009-80, ['Continuidad funcion sen(x)'], ['La funcion sen(x) es continua en todos los numeros reales.'], 20/20, ['Urbaez basado en: http://www.vitutor.com/fun/2/c_15.html']).
pr(0009-81, ['Continuidad funcion cos(x)'], ['La funcion cos(x) es continua en todos los numeros reales.'], 20/20, ['Urbaez basado en: http://www.vitutor.com/fun/2/c_15.html']).
pr(0009-82, ['Rango de la funcion sen(x)'], ['El rango de la funcion sen(x) es [-1,1].]'], 20/20, ['Urbaez basado en: http://www.vitutor.com/fun/2/c_15.html']).
pr(0009-83, ['Rango de la funcion cos(x)'], ['El rango de la funcion cos(x) es [-1,1].'], 20/20, ['Urbaez basado en: http://www.vitutor.com/fun/2/c_15.html']).
pr(0009-84, ['Continuidad (1/(x-A)^(N))'], ['La funcion (1/(x-A)^(N)), es continua para todos los numeros reales menos el numero A'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Funci%C3%B3n_continua']).
pr(0009-85, ['Continuidad de un polinomio'], ['Los polinomios son continuas en toda la recta real.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Funci%C3%B3n_continua']).
%Logica
pr(0009-86, ['Logica Difusa'], ['Es la logica que propone un numero infinito de valores de verdad.'], 20/20, ['Urbaez basado en http://es.wikipedia.org/wiki/L%C3%B3gica_difusa']).
pr(0009-87, ['¿Que es una paradoja?'], ['Es un razonamiento en apariencia valido que parte de premisas en apariencia verdaderas, pero que conduce a una contradiccion o una situacion contraria al sentido comun.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Paradoja']).
pr(0009-88, ['¿Que es una premisa?'], ['Idea que se establece para establecer un razonamiento.'], 20/20, ['Urbaez basado en: http://www.wordreference.com/definicion/premisa']).
pr(0009-89, ['Razonamiento deductivo'], ['Nos sirve para establecer una conclusion a partir de una serie de premisas. Este tipo de razonamiento puede ser valido en su forma pero se puede llegar a una conclusion que es falsa.'], 20/20, ['Urbaez basado en: http://definicion.de/razonamiento-deductivo/']).
pr(0009-90, ['¿Que es un juicio?'], ['Un juicio consiste en comparar dos idead para conocer y determinar sus relaciones.'], 20/20, ['Urbaez basado en: http://www.wordreference.com/definicion/juicio']).
pr(0009-91, ['Silogismo'], ['Es una forma de razonamiento deductivo que consta de dos proposiciones como premisas y otra como conclusion, siendo esta ultima una inferencia deductiva de las otras dos. Esta forma de razonamiento fue propuesta por Aristoteles.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Silogismo']).
%Operaciones %Basicas
pr(0009-92, ['A+B ='], ['B+A'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conmutatividad']).
pr(0009-93, ['A*B ='], ['B*A'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conmutatividad']).
pr(0009-94, ['A-B ='], ['-(B-A)'], 20/20, ['Urbaez basado en: http://www.profesorenlinea.cl/matematica/AlgebraBasica.htm']).
%Numeros %complejos
pr(0009-95, ['Representacion de un numero complejo'], ['Los numeros complejos se representan por la letra C y se denotan como z= x+ y*i, donde i es la parte imaginaria y x es la parte real.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_complejo']).
pr(0009-96, ['Matematicas Discretas'], ['Son un area de las matematicas encargadas del estudio de los conjuntos discretos: finitos o infinitos numerables.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Matem%C3%A1ticas_discretas']).
%conjuntos
pr(0009-97, ['¿Que es un conjunto?'], ['Es una coleccion de elementos considerada en si misma como un objeto'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-98, ['Conjunto finito'], ['Un conjunto finito es un conjunto con un numero finito de elementos. Un ejemplo seria el conjunto de los planetas que componen el sistema solar.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conjunto_finito']).
pr(0009-99, ['Conjunto infinito'], ['Un conjunto inifinito es un conjunto con un numero infinito de elementos, tales como el conjunto de los numeros reales,naturales,entre otros.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conjunto_infinito']).
pr(0009-100, ['Igualdad de conjuntos'], ['2 conjuntos son iguales cuando tienen el mismo numero de elementos y estos son iguales.'], 20/20, ['Urbaez tomado de: http://nux.ula.ve/mathematica/conjuntos.pdf']).
pr(0009-101, ['A = {1,2,3,4,5} ,=, B = {1,2,3,5,6}'], ['Los conjuntos A y B no son iguales.'], 20/20, ['Urbaez tomado del libro de matematicas discretas escrito por Kenneth Rosen.']).
pr(0009-102, ['Conjunto vacio'], ['El conjunto vacio es el conjunto que no tiene ningun elementos.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Conjunto_vac%C3%ADo']).
pr(0009-103, ['Subconjunto'], ['Un conjunto A por ejemplo es un subconjunto del conjunto B si cada elemento de A es a su vez un elemento de B.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/Subconjunto']).
pr(0009-104, ['Cardinalidad'], ['La cardinalidad es la cantidad de elementos de un conjunto finito.'], 20/20, ['Urbaez basado en: http://es.wikipedia.org/wiki/N%C3%BAmero_cardinal']).
pr(0009-105, ['Cardinalidad numeros reales'], ['Los numeros reales no tienen cardinalidad ya que es un conjunto infinito.'], 20/20, ['Urbaezbasado en: http://es.wikipedia.org/wiki/N%C3%BAmero_cardinal']).
pr(0009-106, ['Cardinalidad del conjunto de los planetas del sistema solar'], ['La cardinalidad del conjunto de los planetas del sistema solar es 8.'], 20/20, ['Urbaez basado en: http://nux.ula.ve/mathematica/conjuntos.pdf']).
%relaciones
pr(0009-107, ['Determinar el rango de la siguiente relacion: (n,2n)'], ['Numeros pares.'], 20/20, ['Urbaez basado en: http://es.slideshare.net/gutys_ado/dominio-y-rango']).
pr(0009-108, ['Determinar el rango de la siguiente relacion: (n,(n)^(2))'], ['Numeros cuadrados.'], 20/20, ['Urbaez basado en: http://es.slideshare.net/gutys_ado/dominio-y-rango']).
