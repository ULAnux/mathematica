/*IM NOT OWNED THIS CODE
taken from  http://stackoverflow.com/questions/30403834/prolog-combinatorics*/

pick2(L, [M1, M2], Rest) :-
    member(M1, L),   
    delete(L, M1, L1),
    member(M2, L1),
    delete(L1, M2, Rest).

pick3(L, [M1, M2, M3], Rest) :-
    pick2(L, [M1, M2], L1),
    member(M3, L1),
    delete(L1, M3, Rest).

pick4(L,[M1,M2,M3,M4],Rest) :-
    pick3(L, [M1,M2,M3] ,L2),
    member(M4,L2),
    delete(L2,M4,Rest).
