Buenas tardes profesor. 

En "Pag-jhenifer" se encuentra los archivos necesarios de la guia de Estructuras Algebraicas. Hechos por Jhenifer Contreras CI:23726510

En la Carpeta "Pag-Heberto" se encuentran los archivos html de una pagina web llamada Mathematicas, con las guis de conjuntos y logica, en la pagina principal el menu posee los enlaces a su bitacora, los archivos del curso que se encuentran en ulanux y los enlaces a las guias ya mensionadas, ademas de uno que deberia ir directo a la aplicacion que se esta estructurando en el curso.

Tambien un archivo llamado duel.cpp que muestra la idea de los duelos para la aplicacion en el cual realiza 5 preguntas a dos personas y el que tenga mejor puntaje obtiene 50 vidas del perdedor, Nota: Es la version 0.1 a falta de interfaz grafica y base de datos.

Heberto Gutierrez CI:24752816
