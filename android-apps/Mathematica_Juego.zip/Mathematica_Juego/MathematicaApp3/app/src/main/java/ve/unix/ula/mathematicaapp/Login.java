package ve.unix.ula.mathematicaapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Login extends AppCompatActivity {
    private TextView registrase,ErrorUsuario;
    private EditText UserName,Contrasena;
    private Button IniciarSesion;
    private Usuario user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        user = new Usuario();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        registrase = (TextView) findViewById(R.id.registrase);
        ErrorUsuario = (TextView) findViewById(R.id.ErrorUser);
        UserName = (EditText) findViewById(R.id.UserName);
        Contrasena = (EditText) findViewById(R.id.Password);
        IniciarSesion = (Button) findViewById(R.id.Enviar);

        try{
            if(user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt")))))
            {
                Intent intent = new Intent(getApplicationContext(), Menu_opciones.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            }
        } catch (IOException error){

        }

        IniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Enntro", "aqui");
                if(v.getId() == R.id.Enviar){
                    try {
                        if (user.ReadArchivo(new BufferedReader(new InputStreamReader(openFileInput("Usuarios.txt"))),UserName.getText().toString(),Contrasena.getText().toString())) {
                            Intent intent = new Intent(getApplicationContext(),Menu_opciones.class);
                            user.UsuarioActivo(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt",MODE_PRIVATE)));
                            startActivity(intent);
                            finish();
                        }else{
                            ErrorUsuario.setText("Datos No registrados");
                            (new OutputStreamWriter(openFileOutput("Usuarios.txt",MODE_PRIVATE))).write("Ninguno");
                        }
                    }catch (FileNotFoundException Error){
                        Log.e(Error.getMessage(),Error.getMessage());
                    }catch (IOException Error){
                        Log.e(Error.getMessage(),Error.getMessage());
                    }
                }
            }
        });
        registrase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == R.id.registrase){
                    Intent intent = new Intent(getApplicationContext(),Registro.class);
                    startActivity(intent);
                }
            }
        });

    }

}
