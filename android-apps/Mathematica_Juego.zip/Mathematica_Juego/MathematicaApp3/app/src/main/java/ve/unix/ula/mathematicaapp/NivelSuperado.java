package ve.unix.ula.mathematicaapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class NivelSuperado extends AppCompatActivity {
    private Usuario user;
    private int Nivelsuperado,Temasuperado,puntosGanados;
    OnFragmentInteractionListener mListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_nivel_superado);
        Nivelsuperado=getIntent().getExtras().getInt("Nivel");
        Temasuperado =getIntent().getExtras().getInt("Tema");
        try {
            user = new Usuario();
            if(!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(openFileInput("UsuariosActivos.txt"))))) {
                Intent intent =new Intent(getApplicationContext(),Login.class);
                startActivity(intent);
                finish();
            }
            ImageView siguiente =((ImageView)findViewById(R.id.next));
            siguiente.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                        Intent intent = new Intent(getApplicationContext(),Menu_opciones.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();




                }
            });
            Log.e(""+Temasuperado ,""+Nivelsuperado);
            Log.e(""+user.getTema() ,""+user.getNivel());

            if(Temasuperado<user.getTema()){
                        ((TextView)findViewById(R.id.mensaje)).setText("Nivel Superado ha obtenido\n "+0+ " pts.");

                    }else{
                        if(Nivelsuperado<user.getNivel()){
                            ((TextView)findViewById(R.id.mensaje)).setText("Nivel Superado ha obtenido\n "+0+ " pts.");
                        }else{
                            SubirNivel();

                            user.setExp(user.getExp()+getIntent().getExtras().getInt("NumeroPreguntas")*20);
                            user.UsuarioActivo(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt",MODE_PRIVATE)));
                            ((TextView)findViewById(R.id.mensaje)).setText("Nivel Superado ha obtenido\n "+ getIntent().getExtras().getInt("NumeroPreguntas")*20+ " pts.");

                        }

                    }



        }catch (IOException Error){
            Log.e(Error.getMessage(),Error.getMessage());
        }






    }
    public void SubirNivel(){
        if (user.getTema() == 1) {
            if (user.getNivel() == 1){
                user.setNivel(2);
                return;
            }

            if (user.getNivel() == 2) {
                user.setTema(2);
                user.setNivel(1);
                return;
            }
        } else if (user.getTema() == 2) {
            if (user.getNivel() == 1){
                user.setNivel(2);
                return;
            }

            if (user.getNivel() == 2){
                user.setNivel(3);
                return;
            }

            if (user.getNivel() == 3) {
                user.setTema(3);
                user.setNivel(1);
                return;
            }
        } else if (user.getTema() == 3) {
            if (user.getNivel() == 1){
                user.setNivel(2);
                return;
            }

            if (user.getNivel() == 2) {
                user.setNivel(1);
                user.setTema(4);
                return;
            }
        } else if (user.getTema() == 4) {
            if (user.getNivel() == 1){
                user.setNivel(2);
                return;
            }

            if (user.getNivel() == 2){
                user.setNivel(3);
                return;
            }

            if (user.getNivel() == 3) {
                user.setTema(5);
                user.setNivel(1);
                return;
            }
        } else if (user.getTema() == 5) {
            if (user.getNivel() == 1){
                user.setNivel(2);
                return;
            }

            if (user.getNivel() == 2) {
                user.setNivel(3);
                user.setNivel(2);
            }
        }
    }
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void ActualizaUsuarios(Usuario usuarios);
    }
}
