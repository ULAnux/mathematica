package ve.unix.ula.mathematicaapp;

/**
 * Created by mator on 04/12/16.
 */
import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class NuestroBuscador {
    private OnFragmentInteractionListener listener;
    private static int minimum(int a, int b, int c) {
        if(a<=b && a<=c)
        {
            return a;
        }
        if(b<=a && b<=c)
        {
            return b;
        }
        return c;
    }

    public static int computeLevenshteinDistance(String str1, String str2) {
        return computeLevenshteinDistance(str1.toCharArray(),
                str2.toCharArray());
    }

    private static int computeLevenshteinDistance(char [] str1, char [] str2) {
        int [][]distance = new int[str1.length+1][str2.length+1];

        for(int i=0;i<=str1.length;i++)
        {
            distance[i][0]=i;
        }
        for(int j=0;j<=str2.length;j++)
        {
            distance[0][j]=j;
        }
        for(int i=1;i<=str1.length;i++)
        {
            for(int j=1;j<=str2.length;j++)
            {
                distance[i][j]= minimum(distance[i-1][j]+1,
                        distance[i][j-1]+1,
                        distance[i-1][j-1]+
                                ((str1[i-1]==str2[j-1])?0:1));
            }
        }
        return distance[str1.length][str2.length];

    }
    public static String LimpiarString(String palabra){
        String Prohibidas[] = {"¿", "de ","DE ", "De ", "la " , "La ", "LA ", "el ", "El ", "EL ", "ella ", "Ella ", " ELLA ", " lo ",
                " Lo ", " LO ", " las ", " Las ", " LAS ", " ellos ", " Ellos ", " ELLOS ", " ellas ", " Ellas ", " ELLAS ",
                " cual ", " Cual ", " CUAL ", " cuales ", " Cuales ", " CUALES ", " cuál ", " Cuál ", " CUÁL ", " cuáles ",
                " Cuáles ", " CUÁLES ", "que ", " Que ", " QUE ", " qué ", " Qué ", " QUÉ ", " es ", " Es " , " Del ", " del ", " DEL ",
                " Se ", " se " , " otra " , " Otra " , " puede " , " Puede " ," Un ", " un ", " Sobre ", " sobre " ,"-"};

        palabra =palabra.replaceAll("á","a");
        palabra =palabra.replaceAll("é","e");
        palabra =palabra.replaceAll("í","i");
        palabra =palabra.replaceAll("ó","o");
        palabra =palabra.replaceAll("ú","u");

        palabra =palabra.replace('?',' ');
        for(int i=0; i < Prohibidas.length; i++){
            palabra =palabra.replaceAll( Prohibidas[i]," ");
        }

        return palabra;
    }

    public ArrayList<String> BuscarRespuestaoPregunta(Context contex,String usuario, boolean Objetivo){

        ArrayList<String> Respuesta = new ArrayList<String>();
        ArrayList<String> Respuesta1 = new ArrayList<String>();
        ArrayList<String> Respuesta2 = new ArrayList<String>();

        try {




            Respuesta.add("No hay Respuesta");
            int distanciaTotal=500;
            int ValorDistancia=500, Distanciapalabra=0, DistanciaPr=1000 , NumerodeCoincidencias=0, NumeroMenordeConicidencias=-500;
            String pr,UsuariosTokenizados[] = LimpiarString(usuario).split(" ");
            InputStream inputStream =null;
            //inputStream = new FileInputStream( System.getProperty("user.dir") + "/prolog/0027.pl");

            for(int l=0;l<27;l++){
                System.out.println("entro en el archivo " + l);
                    Integer[] valor = new Integer[2];
                    valor[0] = l;
                    this.listener.onFragmentInteraction(valor);
                    if(l==0)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0000);
                    if(l==1)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0001);
                    if(l==2)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0002);
                    if(l==3)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0003);
                    if(l==4)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0004);
                    if(l==5)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0005);
                    if(l==6)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0006);
                    if(l==7)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0007);
                    if(l==8)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0008);
                    if(l==9)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0009);
                    if(l==10)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0010);
                    if(l==11)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0011);
                    if(l==12)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0012);
                    if(l==13)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0013);
                    if(l==14)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0014);
                    if(l==15)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0015);
                    if(l==16)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0016);
                    if(l==17)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0017);
                    if(l==18)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0018);
                    if(l==19)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0019);
                    if(l==20)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0020);
                    if(l==21)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0021);
                    if(l==22)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0022);
                    if(l==23)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0023);
                    if(l==24)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0024);
                    if(l==26)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0026);
                    if(l==25)
                        inputStream = contex.getResources().openRawResource(R.raw.pr0025);






                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));


                    String line;

                    for (int k=0;(line = reader.readLine()) != null;k++) {
                        //System.out.println("entro");
                        Distanciapalabra = 0;


                        if(line.contains("pr(") && (line.charAt(0)!='%')){
                            //System.out.println("entro1");

                            while(!line.contains("]") || !line.contains(")")){
                                line+=reader.readLine();
                            }
                            NumerodeCoincidencias=0;
                            for(int j=0;j<UsuariosTokenizados.length;j++){
                                if(LimpiarString(line).contains(UsuariosTokenizados[j]))
                                    NumerodeCoincidencias++;
                            }
                            if(NumerodeCoincidencias > NumeroMenordeConicidencias){
                                NumeroMenordeConicidencias=NumerodeCoincidencias;
                                Respuesta1.clear();
                                Respuesta1.add(line);
                            }
                            if(NumerodeCoincidencias == NumeroMenordeConicidencias){

                                if(!Respuesta1.contains(line))
                                    Respuesta1.add(line);
                            }
                            //System.out.println(line);
                            String r[] = new String[0];
                            if(Objetivo){
                                String aux = line.substring(line.indexOf(",")+3,line.indexOf("]")) ;
                                if(aux.split(",").length < aux.split(" ").length){
                                    r = LimpiarString(aux).split(" ");
                                }else{
                                    r = LimpiarString(aux).split(",");
                                }
                            }else{
                                System.out.println(line);
                                System.out.println(line.substring(line.indexOf(']')+1).substring(line.substring(line.indexOf(']')+1).indexOf('[')+1 ,line.substring(line.indexOf(']')+1).indexOf("],") ));

			        			/*String aux =line.substring(line.indexOf(']')+1).substring(line.substring(line.indexOf(']')+1).indexOf('[')+1 ,line.substring(line.indexOf(']')+1).indexOf(']') ) ;
			        			if(aux.split(",").length < aux.split(" ").length){
				        			r = LimpiarString(aux).split(" ");
				        		}else{
				        			r = LimpiarString(aux).split(",");
				        		}*/
                            }
                            for(int j=0;j<UsuariosTokenizados.length;j++){
                                ValorDistancia = 500;
                                for(int i=0;i<r.length;i++){

                                    if(!UsuariosTokenizados[j].isEmpty() && !r[i].isEmpty() ){
                                        int aux=computeLevenshteinDistance(r[i].replaceAll(" ", "").replaceAll("'",""), UsuariosTokenizados[j].replaceAll(" ",""));

                                        if(aux<ValorDistancia){
                                            //System.out.println(r[i]+ "-" + UsuariosTokenizados[j] +"-" +  aux  );

                                            ValorDistancia=aux;
                                        }
                                    }
                                }

                                if(!(ValorDistancia==500)){
                                    Distanciapalabra+=ValorDistancia;

                                }

                            }


                            if(Distanciapalabra < DistanciaPr){
                                DistanciaPr = Distanciapalabra;
                               // System.out.println("Distancia = " + DistanciaPr + " Respuesta " + line );

                                if(l<10)
                                    pr = System.getProperty("user.dir") + "/prolog/000"+l + ".pl";
                                else
                                    pr = System.getProperty("user.dir") + "/prolog/00"+l + ".pl";


                                Respuesta.clear();
                                Respuesta.add(line);/*.substring(line.substring(line.indexOf("[") +1 ).indexOf("["),line.substring(line.substring(line.indexOf("[")).indexOf("[")).indexOf("]"))*/;

                            }
                            if(Distanciapalabra == DistanciaPr && !Respuesta.contains(line)){
                               // System.out.println("Distancia = " + DistanciaPr + " Respuesta " + line );

                                Respuesta.add(line);
                            }




			        		/*System.out.println(line.substring(line.indexOf(",")+3,line.indexOf("]")));
			        		for(int i =0;i<r.length;i++){
			        			System.out.println( r[i]);
			        		}*/
                        }

                    }
                    inputStream.close();
                    reader.close();


            }

           /* for(String a:Respuesta){
                if(Respuesta1.contains(a))
                    Respuesta2.add(a);
                System.out.println("Respuesta="+a);
            }
            for(String a:Respuesta1){
                System.out.println("Respuesta1="+a);
            }
            for(String a:Respuesta2){
                System.out.println("Respuesta2="+a);
            }*/
            if(Respuesta2.isEmpty())
                return Respuesta1;
            return Respuesta2;

            //System.out.println(out.toString() );   //Prints the string content read from input stream
        }catch (IOException error){
            System.out.println(error.getLocalizedMessage()+error.getMessage());
        }
        return Respuesta;

    }
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Integer... values);
    }



}
