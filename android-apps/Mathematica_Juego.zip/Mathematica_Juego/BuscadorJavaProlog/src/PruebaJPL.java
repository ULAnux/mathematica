
import java.util.Iterator;
import java.util.Map;
import org.jpl7.*;

import Windows.PruebaJPLWindows;


	
	
	
	
	
	

public class PruebaJPL {
	public static void main(String[] args) {
		try{
		PruebaJPLWindows window = new PruebaJPLWindows();
		window.setVisible(true);
		System.out.println( System.getProperty("user.dir") +"/lib/libjpl.so"); 

    	String libpath = System.getProperty("java.library.path");
    	libpath = System.getProperty("user.dir")+"/PruebaJPL/lib"+":/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin" ;
    	System.setProperty("java.library.path",libpath);
    	System.out.println(System.getProperty("java.library.path"));
    	
    	System.loadLibrary("jpl");
		//System.load(System.getProperty("user.dir") +"/lib/swi-prolog/lib/i386/libjpl.so");

		}catch (PrologException e) {
			System.out.println(e.getMessage() + e.getLocalizedMessage());
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}

///home/mator/workspace/PruebaJPL/lib:/home/mator/bin:/home/mator/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
