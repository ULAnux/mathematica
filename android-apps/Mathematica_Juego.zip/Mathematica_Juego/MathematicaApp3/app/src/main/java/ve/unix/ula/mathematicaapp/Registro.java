package ve.unix.ula.mathematicaapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import ve.unix.ula.mathematicaapp.Usuario;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Date;

import static java.security.AccessController.getContext;

public class Registro extends AppCompatActivity {

    private int Select = 2;
    private Usuario user;
    private ImageView Enviar;
    private Spinner Sexo;
    private EditText Nombre,UserName,Contrasena, Corrreo, ContrasenaAgain;
    private TextView errorUser, errorContrasena, errorContrasenaAgain, errorName, errorMail, errorSexo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        Enviar = (ImageView) findViewById(R.id.Enviar);
        Nombre = (EditText) findViewById(R.id.Name);
        UserName = (EditText) findViewById(R.id.UserName);
        Contrasena = (EditText) findViewById(R.id.Password);
        ContrasenaAgain = (EditText) findViewById(R.id.PasswordAgain);
        Corrreo = (EditText) findViewById(R.id.Mail);
        Sexo = (Spinner) findViewById(R.id.SexoSpinner);
        errorUser = (TextView) findViewById(R.id.ErrorUser);
        errorContrasena = (TextView) findViewById(R.id.ErrorPasword);
        errorContrasenaAgain = (TextView) findViewById(R.id.ErrorPaswordAgain);
        errorName = (TextView) findViewById(R.id.ErrorName);
        errorMail = (TextView) findViewById(R.id.ErrorMail);
        errorSexo = (TextView) findViewById(R.id.ErrorSexo);

        Nombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.Name){
                    errorName.setText("");
                    ((ImageView) findViewById(R.id.iconoErrorName)).setVisibility(View.INVISIBLE);
                }
            }
        });

        UserName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.UserName){
                    errorUser.setText("");
                    findViewById(R.id.iconoErrorUser).setVisibility(View.INVISIBLE);
                }
            }
        });

        Contrasena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.Password){
                    errorContrasena.setText("");
                    findViewById(R.id.iconoErrorPasword).setVisibility(View.INVISIBLE);
                }
            }
        });

        ContrasenaAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.PasswordAgain){
                    errorContrasenaAgain.setText("");
                    findViewById(R.id.iconoErrorPasworAgain).setVisibility(View.INVISIBLE);
                }
            }
        });

        Corrreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()==R.id.Mail){
                    errorMail.setText("");
                    findViewById(R.id.iconoErrorMail).setVisibility(View.INVISIBLE);
                }
            }
        });





        String[] valores = {"Genero","Femenino","Masculino"};
        ArrayAdapter adapter = new ArrayAdapter<String>(Registro.this, android.R.layout.simple_spinner_dropdown_item, valores);
        Sexo.setAdapter(adapter);

        Sexo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                errorSexo.setText("");
                findViewById(R.id.iconoErrorSexo).setVisibility(View.INVISIBLE);
                if(id == 0){
                    Select = 2;
                } else if(id == 1) {
                    Select = 0;
                } else if(id == 2){
                    Select = 1;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId()== R.id.Enviar){
                    try{

                        BufferedReader fin = new BufferedReader(new InputStreamReader(openFileInput("Usuarios.txt")));
                        String Line;
                        Boolean estado = true;
                        while((Line = fin.readLine())!= null){
                            if(Line.substring(0,Line.indexOf(":")).equals(UserName.getText().toString())){
                                errorUser.setText("Este nombre de usuario ya se encuentra en uso. Por favor intente con otro");
                                findViewById(R.id.iconoErrorUser).setVisibility(View.VISIBLE);
                                Log.e("error","username");
                                estado = false;
                            }
                        }



                        if(UserName.getText().toString().isEmpty()){
                            errorUser.setText("Debe ingresar un nombre de usuario");
                            findViewById(R.id.iconoErrorUser).setVisibility(View.VISIBLE);
                            estado = false;
                        }

                        if(Contrasena.getText().toString().isEmpty()){
                            errorContrasena.setText("Debe ingresar una contraseña");
                            findViewById(R.id.iconoErrorPasword).setVisibility(View.VISIBLE);
                            estado = false;
                        }

                        if(ContrasenaAgain.getText().toString().isEmpty()){
                            errorContrasenaAgain.setText("Debe repetir su contraseña");
                            estado = false;
                        }

                        if(!Contrasena.getText().toString().equals(ContrasenaAgain.getText().toString())){
                            errorContrasenaAgain.setText("Su contraseña no coincide");
                            estado = false;
                        }

                        if(Nombre.getText().toString().isEmpty()){
                            errorName.setText("Debe ingresar un nombre");
                            findViewById(R.id.iconoErrorName).setVisibility(View.VISIBLE);
                            estado = false;
                        }
                        if(Select == 2) {
                            errorSexo.setText("Seleccione una opción");
                            findViewById(R.id.iconoErrorSexo).setVisibility(View.VISIBLE);
                            estado = false;
                        }

                        if(Corrreo.getText().toString().isEmpty()){
                            errorMail.setText("Debe ingresar un correo");
                            findViewById(R.id.iconoErrorMail).setVisibility(View.VISIBLE);
                            estado = false;
                        } else if(!(Corrreo.getText().toString().contains("@") && Corrreo.getText().toString().contains(".com"))){
                            errorMail.setText("Debe ingresar un correo válido");
                            findViewById(R.id.iconoErrorMail).setVisibility(View.VISIBLE);
                            estado = false;
                        }

                        if(!estado)
                            return;




                        user = new Usuario(UserName.getText().toString(),Contrasena.getText().toString(),Nombre.getText().toString(),Corrreo.getText().toString(), Select, 1,0,1,0,0);
                        user.writeArchivo(new OutputStreamWriter(openFileOutput("Usuarios.txt",MODE_APPEND)));
                        user.UsuarioActivo(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt",MODE_PRIVATE)));
                        Intent intent = new Intent(getApplicationContext(),Tutorial.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    }catch (IOException error){
                        try {
                            Boolean estado = true;

                            if(UserName.getText().toString().isEmpty()){
                                errorUser.setText("Debe ingresar un nombre de usuario");
                                findViewById(R.id.iconoErrorUser).setVisibility(View.VISIBLE);
                                estado = false;
                            }

                            if(Contrasena.getText().toString().isEmpty()){
                                errorContrasena.setText("Debe ingresar una contraseña");
                                findViewById(R.id.iconoErrorPasword).setVisibility(View.VISIBLE);
                                estado = false;
                            }

                            if(ContrasenaAgain.getText().toString().isEmpty()){
                                errorContrasenaAgain.setText("Debe repetir su contraseña");
                                estado = false;
                            }

                            if(!Contrasena.getText().toString().equals(ContrasenaAgain.getText().toString())){
                                errorContrasenaAgain.setText("Su contraseña no coincide");
                                estado = false;
                            }

                            if(Nombre.getText().toString().isEmpty()){
                                errorName.setText("Debe ingresar un nombre");
                                findViewById(R.id.iconoErrorName).setVisibility(View.VISIBLE);
                                estado = false;
                            }
                            if(Select == 2) {
                                errorSexo.setText("Seleccione una opción");
                                findViewById(R.id.iconoErrorSexo).setVisibility(View.VISIBLE);
                                estado = false;
                            }

                            if(Corrreo.getText().toString().isEmpty()){
                                errorMail.setText("Debe ingresar un correo");
                                findViewById(R.id.iconoErrorMail).setVisibility(View.VISIBLE);
                                estado = false;
                            } else if(!(Corrreo.getText().toString().contains("@") && Corrreo.getText().toString().contains(".com"))){
                                errorMail.setText("Debe ingresar un correo válido");
                                findViewById(R.id.iconoErrorMail).setVisibility(View.VISIBLE);
                                estado = false;
                            }

                            if(!estado)
                                return;



                            user = new Usuario(UserName.getText().toString(), Contrasena.getText().toString(), Nombre.getText().toString(), Corrreo.getText().toString(), Select, 1, 0,1,0,0);
                            user.writeArchivo(new OutputStreamWriter(openFileOutput("Usuarios.txt", MODE_PRIVATE)));
                            Intent intent = new Intent(getApplicationContext(), Tutorial.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            user.UsuarioActivo(new OutputStreamWriter(openFileOutput("UsuariosActivos.txt",MODE_PRIVATE)));
                            startActivity(intent);
                            finish();
                        }catch (FileNotFoundException Error){
                            Log.e(Error.getMessage(),Error.getLocalizedMessage());
                        }
                    }
                }
            }
        });



    }
}
