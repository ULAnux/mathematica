package ve.unix.ula.mathematicaapp;

import android.app.Fragment;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.*;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static android.app.Instrumentation.*;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link frament_Juego.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link frament_Juego#newInstance} factory method to
 * create an instance of this fragment.
 */
public class frament_Juego extends android.support.v4.app.Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private Usuario user;
    private ImageView Logica,Conjuntos, Combinatioria,Variaciones,Permutaciones;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public frament_Juego() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment frament_Juego.
     */
    // TODO: Rename and change types and number of parameters
    public static frament_Juego newInstance(String param1, String param2) {
        frament_Juego fragment = new frament_Juego();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_frament__juego, container, false);
        this.Logica  = (ImageView) rootView.findViewById(R.id.Logica);
        this.Combinatioria = (ImageView) rootView.findViewById(R.id.Combinatoria);
        this.Conjuntos = (ImageView) rootView.findViewById(R.id.Conjuntos);
        this.Variaciones = (ImageView)rootView.findViewById(R.id.Variaciones);
        this.Permutaciones = (ImageView)rootView.findViewById(R.id.Permutaciones);
        if(user.getTema()==1){
            this.Logica.setImageResource(R.drawable.logica_a);

        }
        if(user.getTema()==2){
            this.Logica.setImageResource(R.drawable.logica_a);
            this.Conjuntos.setImageResource(R.drawable.conjuntocolor2);

        }
        if(user.getTema()==3){
            this.Logica.setImageResource(R.drawable.logica_a);
            this.Conjuntos.setImageResource(R.drawable.conjuntocolor2);
            this.Variaciones.setImageResource(R.drawable.estructurascolor);

        }
        if(user.getTema()==4){
            this.Logica.setImageResource(R.drawable.logica_a);
            this.Combinatioria.setImageResource(R.drawable.combinatoriacolor);
            this.Conjuntos.setImageResource(R.drawable.conjuntocolor2);
            this.Variaciones.setImageResource(R.drawable.estructurascolor);

        }
        if(user.getTema()==5){
            this.Logica.setImageResource(R.drawable.logica_a);
            this.Combinatioria.setImageResource(R.drawable.combinatoriacolor);
            this.Conjuntos.setImageResource(R.drawable.conjuntocolor2);
            this.Variaciones.setImageResource(R.drawable.estructurascolor);
            this.Permutaciones.setImageResource(R.drawable.recurrenciacolor);
        }
        Logica.setOnClickListener(this);
        Conjuntos.setOnClickListener(this);
        Combinatioria.setOnClickListener(this);
        Variaciones.setOnClickListener(this);
        Permutaciones.setOnClickListener(this);


        // Inflate the layout for this fragment


        return rootView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(user);
        }
    }

    @Override
    public void onAttach(Context context) {
        user  = new Usuario();
        try {
            if (!user.LLenarseUsuarioActivo(new BufferedReader(new InputStreamReader(context.openFileInput("UsuariosActivos.txt"))))) {
                Intent intent = new Intent(context, Login.class);
                startActivity(intent);
            }

        } catch (IOException Error) {
            Log.e(Error.getMessage(), Error.getMessage());
        }
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }
    public void Recibir(Usuario user){
        if(user != null){
            this.user = user;
        }else{
            this.user = new Usuario();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(getContext(),Niveles.class);
        switch (v.getId()){

            case R.id.Logica:
                intent.putExtra("Tema",1);
                startActivity(intent);
                break;
            case R.id.Conjuntos:
                if(user.getTema() >=2) {
                    intent.putExtra("Tema", 2);
                    startActivityForResult(intent, 1);
                }else{
                    Toast.makeText(getContext(),"No has llegado a este tema todavía.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.Variaciones:
                if(user.getTema() >=3) {
                    intent.putExtra("Tema",3);
                    startActivityForResult(intent, 1);
                }else{
                    Toast.makeText(getContext(),"No has llegado a este tema todavía.",Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.Combinatoria:
                if(user.getTema() >=4) {
                    intent.putExtra("Tema",4);
                    startActivityForResult(intent, 1);
                }else{
                    Toast.makeText(getContext(),"No has llegado a este tema todavía.",Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.Permutaciones:
                if(user.getTema() >=4) {
                    intent.putExtra("Tema",5);
                    startActivityForResult(intent, 1);
                }else{
                    Toast.makeText(getContext(),"No has llegado a este tema todavía.",Toast.LENGTH_SHORT).show();
                }

                break;



        }
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Usuario usuario);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        Log.e(""+requestCode, ""+requestCode + "entro en el callbal de que se cerro");
        if ((resultCode == 1)){
            mListener.onFragmentInteraction(user);
        }
    }
}
